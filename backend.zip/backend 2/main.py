from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import os
from database import SessionLocal, engine, Base
from models import *
from func import *
import logging
from fastapi.responses import HTMLResponse, JSONResponse
from typing import Any
from fastapi import FastAPI, Query
from fastapi.responses import FileResponse
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg
from reportlab.platypus.flowables import Flowable


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("app.log", encoding='utf-8'),  # Запись логов в файл app.log
        logging.StreamHandler()            # Также выводим логи в консоль
    ]
)
logger = logging.getLogger(__name__)


# Создание директории для загрузок, если её нет
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Создание таблиц
Base.metadata.create_all(bind=engine)

# Инициализация FastAPI
app = FastAPI()

# Монтируем директорию uploads для раздачи статических файлов
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",  # Vite dev server
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
@app.get("/listcompanies", response_model=List[CompanySchema])
def get_companies(db: Session = Depends(get_db)):
    companies = db.query(Company).all()
    return [
        CompanySchema(
            id=company.id,
            email=company.email,
            name=company.name,
            description=company.description,
            partners=company.partners.split(',')  # превращаем строку в список
        )
        for company in companies
    ]

pdfmetrics.registerFont(TTFont('DejaVuSans', 'DejaVuSans.ttf'))

class SVGID(Flowable):
    def __init__(self, path, width=200, height=80):
        Flowable.__init__(self)
        self.drawing = svg2rlg(path)
        scale_x = width / self.drawing.width
        scale_y = height / self.drawing.height
        self.drawing.scale(scale_x, scale_y)
        self.width = width
        self.height = height

    def draw(self):
        renderPDF.draw(self.drawing, self.canv, self.drawing.width - 20 , 0)


@app.get("/generate-pdf")
async def generate_pdf(
    bonus_company: str = Query(...),
    bonus_name: str = Query(...),
    id: str = Query(...)
):
    pdf_file_path = "output.pdf"

    doc = SimpleDocTemplate(pdf_file_path, pagesize=letter,
                            rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=72)

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        name='TitleStyle',
        parent=styles['Title'],
        fontName='DejaVuSans',
        fontSize=24,
        leading=30,
        alignment=TA_CENTER,
        textColor=colors.darkblue,
        spaceAfter=20
    )

    normal_centered = ParagraphStyle(
        name='CustomNormal',
        fontName='DejaVuSans',
        fontSize=14,
        leading=20,
        alignment=TA_CENTER,
        textColor=colors.black
    )

    signature_style = ParagraphStyle(
        name='Signature',
        fontName='DejaVuSans',
        fontSize=12,
        alignment=TA_CENTER,
        spaceBefore=40
    )

    story = []

    # Вставка PNG изображения
    story.append(Image("pulse.png", width=230, height=50))
    story.append(Spacer(1, 1))

    # Заголовок
    story.append(Paragraph("<br/><b>СЕРТИФИКАТ О ПОЛУЧЕНИИ БОНУСА</b>", title_style))
    story.append(Spacer(1, 12))

    # Основной текст
    story.append(Paragraph(f"""
        Этот сертификат подтверждает, что волонтёр <b>{id}</b> проявил выдающиеся качества и активно участвовал в бонусной программе {bonus_company}.<br/><br/>
        Мы высоко ценим ваш вклад и усилия, которые вы приложили для достижения общих целей.<br/><br/>
        Ваши действия вдохновляют других и делают мир лучше. Вы — настоящий пример для подражания!<br/><br/>
        Мы рады вручить вам бонус: <b>{bonus_name}</b>, как знак нашей благодарности за вашу работу и преданность делу.<br/><br/>
        Спасибо за вашу самоотверженность и стремление помогать другим. Вы — молодец!
    """, normal_centered))

    # Подпись
    story.append(Paragraph("______________________________<br/>Электронная подпись", signature_style))
    story.append(Spacer(1, 30))

    # SVG внизу (например, ID или логотип)
    story.append(SVGID("id.svg", 100, 20))

    doc.build(story)

    return FileResponse(pdf_file_path, media_type='application/pdf', filename="output.pdf")


@app.post("/company/register")
async def register_company(
    name: str = Form(...),
    description: str = Form(...),
    partners: str = Form(...),
    icon_png: UploadFile = File(...),
    #user_type: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    try:
        #print(f"Получены данные: name={name}, email={email}, user_type={user_type}")
        
        # Проверяем, не существует ли уже компания с таким email
        existing_company = db.query(Company).filter(Company.email == email).first()
        if existing_company:
            return JSONResponse(
                status_code=400,
                content={"message": "Компания с таким email уже существует"}
            )

        # Проверка расширения файла
        if not icon_png.filename.endswith('.png'):
            return JSONResponse(
                status_code=400,
                content={"message": "Файл должен быть в формате PNG."}
            )

        print("Сохраняем файл...")
        # Сохранение файла
        file_location = f"uploads/{icon_png.filename}"
        os.makedirs("uploads", exist_ok=True)
        
        with open(file_location, "wb") as buffer:
            content = await icon_png.read()
            print(f"Размер файла: {len(content)} байт")
            buffer.write(content)

        print("Хешируем пароль...")
        # Хешируем пароль
        hashed_password = get_password_hash(password)

        print("Создаем запись в БД...")
        # Создание и сохранение компании
        company = Company(
            name=name,
            description=description,
            partners=partners,
            icon_path=file_location,
            #user_type=,
            email=email,
            hashed_password=hashed_password
        )
        
        db.add(company)
        db.commit()
        db.refresh(company)

        print("Создаем токен...")
        # Создаем токен для автоматического входа после регистрации
        access_token = create_access_token(data={"sub": str(company.id)})

        return JSONResponse(
            status_code=201,
            content={
                "message": "Компания успешно зарегистрирована!",
                "access_token": access_token,
                "token_type": "bearer",
                "company": {
                    "id": company.id,
                    "name": company.name,
                    "description": company.description,
                    "partners": partners.split(','),
                    "icon_path": company.icon_path,
                    "email": company.email
                }
            }
        )

    except Exception as e:
        print(f"Ошибка при регистрации: {str(e)}")
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={
                "status": "error",
                "message": str(e)
            }
        )

@app.post("/company/login", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    #user_type: str = Form(...)
):
    try:
        print(f"Попытка входа для пользователя: {form_data.username}")
        #print(f"Тип пользователя: {user_type}")
        
        db = SessionLocal()
        try:
            company = db.query(Company).filter(Company.email == form_data.username).first()
            
            if not company:
                print(f"Компания с email {form_data.username} не найдена")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный email или пароль",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            
            # Проверяем соответствие типа пользователя
            #if company.user_type != user_type:
           #     print(f"Неверный тип пользователя: ожидается {company.user_type}, получен {user_type}")
           #     raise HTTPException(
           #         status_code=401,
           #         detail="Неверный тип пользователя",
           #         headers={"WWW-Authenticate": "Bearer"},
           #     )
                
            if not verify_password(form_data.password, company.hashed_password):
                print(f"Неверный пароль для компании {form_data.username}")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный email или пароль",
                    headers={"WWW-Authenticate": "Bearer"},
                )
                
            access_token = create_access_token(data={"sub": str(company.id)})
            print(f"Успешный вход для компании {form_data.username}")
            return {"access_token": access_token, "token_type": "bearer"}
            
        finally:
            db.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Неожиданная ошибка при входе: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Внутренняя ошибка сервера: {str(e)}"
        )

@app.get("/company/profile")
async def get_company_profile(current_company: Company = Depends(get_current_company)):
    return {
        "id": current_company.id,
        "name": current_company.name,
        "description": current_company.description,
        "partners": current_company.partners.split(','),
        "icon_path": current_company.icon_path,
        "email": current_company.email
    }



@app.post("/volonter/register")
async def register_user(inn: int, email: str, password: str):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == email, User.inn == inn).first()

        if user is None:
            raise HTTPException(status_code=404, detail="Такого пользователя нету.")
    
        if user.pasw:
            raise HTTPException(status_code=400, detail="Пользователь уже зарегистрирован.")
        else:
            # hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
            hashed_password = get_password_hash(password)
            user.pasw = hashed_password
            user.volunteer_id = generate_volunteer_code()
            db.commit()
            return {"message": "OK"}
    finally:
        db.close()



@app.post("/volonter/login", response_model=Token)
async def volonter_login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    user_type: str = Form(...)
):
    try:
        print(f"Попытка входа для пользователя: {form_data.username}")
        print(f"Тип пользователя: {user_type}")
        
        db = SessionLocal()
        try:
            user = db.query(User).filter(User.email == form_data.username).first()
            
            if not user:
                print(f"Пользователь с email {form_data.username} не найден")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный email или пароль",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            
            if user.roles != 0:
                print(f"Неверный тип пользователя")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный тип пользователя",
                    headers={"WWW-Authenticate": "Bearer"},
                )
                
            if not verify_password(form_data.password, user.pasw):
                print(f"Неверный пароль для пользователя {form_data.username}")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный email или пароль",
                    headers={"WWW-Authenticate": "Bearer"},
                )
                
            access_token = create_access_token(data={"sub": str(user.id)})
            print(f"Успешный вход для пользователя {form_data.username}")
            return {"access_token": access_token, "token_type": "bearer"}
            
        finally:
            db.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Неожиданная ошибка при входе: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Внутренняя ошибка сервера: {str(e)}"
        )


@app.get("/listvolonter", response_model=list)
def read_volunteers(db: Session = Depends(get_db)):
    volunteers = db.query(User).all()
    listtop = []
    for volunteer in volunteers:
        if volunteer.volunteer_id == "":
            listtop.append({"volunteer_id": "Пользователь не зарегистрирован", "achievements": volunteer.achievements})
        else:
            listtop.append({"volunteer_id": volunteer.volunteer_id, "achievements": volunteer.achievements})
    return listtop


@app.get("/adminlistvolonter", response_model=list)
def read_volunteers(db: Session = Depends(get_db)):
    volunteers = db.query(User).all()
    listtop = []
    for volunteer in volunteers:
        if volunteer.volunteer_id == "":
            listtop.append({
                "id": volunteer.id,
                "full_name": volunteer.full_name,
                "inn": volunteer.inn,
                "phone_number": volunteer.phone_number,
                "email": volunteer.email,
                "birth_date": volunteer.birth_date,
                "achievements": volunteer.achievements,
                "points": volunteer.points,
                "volunteer_id": "Пользователь не зарегистрирован",
                "roles": volunteer.roles
            })
        else:
            listtop.append({
                "id": volunteer.id,
                "full_name": volunteer.full_name,
                "inn": volunteer.inn,
                "phone_number": volunteer.phone_number,
                "email": volunteer.email,
                "birth_date": volunteer.birth_date,
                "achievements": volunteer.achievements,
                "points": volunteer.points,
                "volunteer_id": volunteer.volunteer_id,
                "roles": volunteer.roles
            })
    return listtop

@app.post("/admin/login", response_model=Token)
async def admin_login(
    form_data: OAuth2PasswordRequestForm = Depends()
):
    try:
        print(f"Попытка входа для администратора: {form_data.username}")
        
        db = SessionLocal()
        try:
            user = db.query(User).filter(User.email == form_data.username).first()
            
            if not user:
                print(f"Пользователь с email {form_data.username} не найден")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный email или пароль",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            
            if user.roles != 1:  # 1 - роль администратора
                print(f"Пользователь не является администратором")
                raise HTTPException(
                    status_code=401,
                    detail="Доступ запрещен",
                    headers={"WWW-Authenticate": "Bearer"},
                )
                
            if not verify_password(form_data.password, user.pasw):
                print(f"Неверный пароль для администратора {form_data.username}")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный email или пароль",
                    headers={"WWW-Authenticate": "Bearer"},
                )
                
            access_token = create_access_token(data={"sub": str(user.id)})
            print(f"Успешный вход для администратора {form_data.username}")
            return {"access_token": access_token, "token_type": "bearer"}
            
        finally:
            db.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Неожиданная ошибка при входе: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Внутренняя ошибка сервера: {str(e)}"
        )







@app.get("/volonter/profile")
async def get_volonter_profile(current_volonter: User = Depends(get_current_volonter)):
    return {
        "id": current_volonter.id, 
        "full_name":current_volonter.full_name,
        "inn":current_volonter.inn, 
        "phone_number":current_volonter.phone_number, 
        "email":current_volonter.email, 
        "birth_date":current_volonter.birth_date, 
        "achievements":current_volonter.achievements, 
        "points":current_volonter.points,
        "volunteer_id":current_volonter.volunteer_id 
    }


@app.post("/bonuses/")
def create_bonus(bonus: BonusCreate, db: Session = Depends(get_db)):
    logger.info("Создание бонуса: %s", bonus.dict())
    db_bonus = Bonus(**bonus.dict())
    db.add(db_bonus)
    db.commit()
    db.refresh(db_bonus)
    logger.info("Бонус успешно создан: %s", bonus.dict())
    return db_bonus

@app.get("/bonusesinapplicable/", response_model=List[BonusResponse])
def get_bonuses_by_applicable_range(iduser: int, db: Session = Depends(get_db)):
    if iduser <= 50:
        applicable_range = 0
    elif iduser > 50 and iduser <=100:
        applicable_range = 1
    elif iduser > 100 and iduser <=150:
        applicable_range = 2
    bonuses = db.query(Bonus).filter(Bonus.applicable_range == applicable_range).all()
    if not bonuses:
        raise HTTPException(status_code=404, detail="No bonuses found for this applicable range")
    return bonuses

@app.delete("/bonuses/{bonus_id}")
def delete_bonus(bonus_id: int):
    with Session(engine) as session:
        bonus = session.get(Bonus, bonus_id)
        logger.info("Удаление бонуса: id: %s applicable_range: %s name: %s organizer: %s", bonus.id, bonus.applicable_range, bonus.name, bonus.organizer)
        if not bonus:
            raise HTTPException(status_code=404, detail="Bonus not found")
        session.delete(bonus)
        session.commit()
        return {"ok": True}
    

@app.patch("/bonuses/{bonus_id}", response_model=BonusResponse)
def update_bonus(bonus_id: int, bonus: BonusCreate, db: Session = Depends(get_db)):
    existing_bonus = db.get(Bonus, bonus_id)
    if not existing_bonus:
        raise HTTPException(status_code=404, detail="Bonus not found")
    logger.info("Изменение бонуса: id: %s applicable_range: %s name: %s organizer: %s на applicable_range: %s name: %s organizer: %s", existing_bonus.id, existing_bonus.applicable_range, existing_bonus.name, existing_bonus.organizer, bonus.applicable_range, bonus.name, bonus.organizer)
    existing_bonus.applicable_range = bonus.applicable_range
    existing_bonus.name = bonus.name
    existing_bonus.organizer = bonus.organizer
    
    db.commit()
    db.refresh(existing_bonus)
    return existing_bonus

@app.get("/bonuses/", response_model=List[BonusResponse])
def get_bonuses_by_organizer(organizer: str, db: Session = Depends(get_db)):
    bonuses = db.query(Bonus).filter(Bonus.organizer == organizer).all()
    if not bonuses:
        raise HTTPException(status_code=404, detail="No bonuses found for this organizer")
    return bonuses


@app.get("/bonusesinapplicable/", response_model=List[BonusResponse])
def get_bonuses_by_applicable_range(iduser: int, db: Session = Depends(get_db)):
    if iduser <= 50:
        applicable_range = 0
    elif iduser > 50 and iduser <=100:
        applicable_range = 1
    elif iduser > 100 and iduser <=150:
        applicable_range = 2
    bonuses = db.query(Bonus).filter(Bonus.applicable_range == applicable_range).all()
    if not bonuses:
        raise HTTPException(status_code=404, detail="No bonuses found for this applicable range")
    return bonuses
@app.post("/edit_user")
async def edit_user(user_id: int = Form(...), name: str = Form(...), email: str = Form(...), db: Session = Depends(get_db)):
    # Поиск пользователя в базе данных по user_id
    user = db.query(User).filter(User.id == user_id).first()
    
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Обновление данных пользователя
    user.full_name = name
    user.email = email
    
    # Сохранение изменений в базе данных
    db.commit()
    db.refresh(user)
    
    return {"message": "User updated successfully", "user": {"id": user.id, "name": user.full_name, "email": user.email}}

@app.post("/edit_company")
async def edit_company(
    company_id: int = Form(...),
    name: str = Form(...),
    email: str = Form(...),
    description: str = Form(...),
    partners: str = Form(...),  # ожидаем «partner1,partner2,…»
    db: Session = Depends(get_db),
) -> Any:
    # Ищем компанию
    company = db.query(Company).filter(Company.id == company_id).first()
    if company is None:
        raise HTTPException(status_code=404, detail="Company not found")

    # Обновляем поля
    company.name = name
    company.email = email
    company.description = description
    company.partners = partners  # сохраняем в БД как CSV

    # Сохраняем
    db.commit()
    db.refresh(company)

    # Формируем ответ: превращаем partners в список
    partners_list: List[str] = [p.strip() for p in company.partners.split(",") if p.strip()]

    return JSONResponse({
        "message": "Company updated successfully",
        "company": {
            "id": company.id,
            "name": company.name,
            "email": company.email,
            "description": company.description,
            "partners": partners_list,
        }
    })

LOG_FILE_PATH = "app.log"

@app.get("/log", response_class=HTMLResponse)
async def view_logs():
    # Проверяем, существует ли файл
    if not os.path.exists(LOG_FILE_PATH):
        raise HTTPException(status_code=404, detail="Log file not found")
    
    # Читаем содержимое файла
    with open(LOG_FILE_PATH, "r") as log_file:
        log_content = log_file.read()
    
    # Форматируем содержимое для отображения в HTML
    return f"<html><body><pre>{log_content}</pre></body></html>"

@app.get("/companies")
async def read_companies(db: Session = Depends(get_db)):
    companies = db.query(Company).all()
    return [{"name": company.name, "description": company.description, "icon_path": company.icon_path} for company in companies]

if not os.path.exists("uploads"):
    os.makedirs("uploads")

# Монтируем папку uploads
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000) 

