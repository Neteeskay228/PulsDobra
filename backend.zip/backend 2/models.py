from sqlalchemy import Column, Integer, String, Text
from database import Base
from pydantic import BaseModel
from typing import List

class Company(Base):
    __tablename__ = 'companies'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=False)
    partners = Column(Text, nullable=False)
    icon_path = Column(String(200), nullable=False)
    #user_type = Column(String(50), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String(200), nullable=False) 


class CompanySchema(BaseModel):
    id: int
    name: str
    email: str
    description: str
    partners: List[str]

class Token(BaseModel):
    access_token: str
    token_type: str

class CompanyLogin(BaseModel):
    email: str
    password: str

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String)
    inn = Column(Integer)
    phone_number = Column(String)
    email = Column(String, unique=True)
    birth_date = Column(String)
    achievements = Column(String)
    points = Column(Integer)
    volunteer_id = Column(Integer)
    roles = Column(Integer)
    pasw = Column(String, nullable=True)

class BonusCreate(BaseModel):
    name: str
    applicable_range: int
    organizer: str

class BonusResponse(BaseModel):
    id: int
    name: str
    applicable_range: int
    organizer: str

    class Config:
        orm_mode = True


class Bonus(Base):
    __tablename__ = 'bonuses'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    applicable_range = Column(Integer)
    organizer = Column(String)
