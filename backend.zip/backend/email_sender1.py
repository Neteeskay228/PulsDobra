import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# данные
# sender_email = "pulsdobra@yandex.ru"
# app_password = "qfcjtphdzxinfvqg"
receiver_email = "denchik.d07@yandex.ru"


MAIL_SERVER = "smtp.mail.ru"
MAIL_PORT = 587
MAIL_USE_TLS = True
sender_email = "bytefire@mail.ru"
app_password = "Lf7TaPZ6TM6zQXFpCP4Y"

# прикрепляем обе версии


message = MIMEMultipart("alternative")
message["Subject"] = "Пример письма"
message["From"] = sender_email
message["To"] = receiver_email

# обычный текст
text = "Привет! Это текстовая версия письма. Если не видно HTML — прочитай это."

# HTML
html = """
<html>
  <body>
    <h2>Привет!</h2>
    <p>Это HTML-письмо. Всё отлично!</p>
  </body>
</html>
"""

# прикрепляем оба варианта
message.attach(MIMEText(text, "plain"))
message.attach(MIMEText(html, "html"))

# отправка
with smtplib.SMTP(MAIL_SERVER, MAIL_PORT) as server:
    server.starttls()  # включаем TLS
    server.login(sender_email, app_password)
    server.sendmail(sender_email, receiver_email, message.as_string())

print("HTML-письмо отправлено!")