from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from sqlalchemy.orm import Session
import os
from datetime import datetime, timedelta
import jwt
from passlib.context import CryptContext
from database import SessionLocal, engine, Base
from models import Company

# Создание директории для загрузок, если её нет
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Настройки JWT
SECRET_KEY = "your-secret-key"  # В продакшене использовать безопасный ключ
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Создание таблиц
Base.metadata.create_all(bind=engine)

# Инициализация FastAPI
app = FastAPI()

# Монтируем директорию uploads для раздачи статических файлов
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",  # Vite dev server
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency для получения сессии БД
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Модель для данных компании
class CompanySchema(BaseModel):
    name: str
    description: str
    partners: List[str]

class Token(BaseModel):
    access_token: str
    token_type: str

class CompanyLogin(BaseModel):
    email: str
    password: str

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_company(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=401,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        company_id: str = payload.get("sub")
        if company_id is None:
            raise credentials_exception
    except jwt.JWTError:
        raise credentials_exception
    
    company = db.query(Company).filter(Company.id == company_id).first()
    if company is None:
        raise credentials_exception
    return company

@app.post("/register")
async def register_company(
    name: str = Form(...),
    description: str = Form(...),
    partners: str = Form(...),
    icon_png: UploadFile = File(...),
    user_type: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    try:
        print(f"Получены данные: name={name}, email={email}, user_type={user_type}")
        
        # Проверяем, не существует ли уже компания с таким email
        existing_company = db.query(Company).filter(Company.email == email).first()
        if existing_company:
            return JSONResponse(
                status_code=400,
                content={"message": "Компания с таким email уже существует"}
            )

        # Проверка расширения файла
        if not icon_png.filename.endswith('.png'):
            return JSONResponse(
                status_code=400,
                content={"message": "Файл должен быть в формате PNG."}
            )

        print("Сохраняем файл...")
        # Сохранение файла
        file_location = f"uploads/{icon_png.filename}"
        os.makedirs("uploads", exist_ok=True)
        
        with open(file_location, "wb") as buffer:
            content = await icon_png.read()
            print(f"Размер файла: {len(content)} байт")
            buffer.write(content)

        print("Хешируем пароль...")
        # Хешируем пароль
        hashed_password = get_password_hash(password)

        print("Создаем запись в БД...")
        # Создание и сохранение компании
        company = Company(
            name=name,
            description=description,
            partners=partners,
            icon_path=file_location,
            user_type=user_type,
            email=email,
            hashed_password=hashed_password
        )
        
        db.add(company)
        db.commit()
        db.refresh(company)

        print("Создаем токен...")
        # Создаем токен для автоматического входа после регистрации
        access_token = create_access_token(data={"sub": str(company.id)})

        return JSONResponse(
            status_code=201,
            content={
                "message": "Компания успешно зарегистрирована!",
                "access_token": access_token,
                "token_type": "bearer",
                "company": {
                    "id": company.id,
                    "name": company.name,
                    "description": company.description,
                    "partners": partners.split(','),
                    "icon_path": company.icon_path,
                    "user_type": company.user_type,
                    "email": company.email
                }
            }
        )

    except Exception as e:
        print(f"Ошибка при регистрации: {str(e)}")
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={
                "status": "error",
                "message": str(e)
            }
        )

@app.post("/login", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    user_type: str = Form(...)
):
    try:
        print(f"Попытка входа для пользователя: {form_data.username}")
        print(f"Тип пользователя: {user_type}")
        
        db = SessionLocal()
        try:
            company = db.query(Company).filter(Company.email == form_data.username).first()
            
            if not company:
                print(f"Компания с email {form_data.username} не найдена")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный email или пароль",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            
            # Проверяем соответствие типа пользователя
            if company.user_type != user_type:
                print(f"Неверный тип пользователя: ожидается {company.user_type}, получен {user_type}")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный тип пользователя",
                    headers={"WWW-Authenticate": "Bearer"},
                )
                
            if not verify_password(form_data.password, company.hashed_password):
                print(f"Неверный пароль для компании {form_data.username}")
                raise HTTPException(
                    status_code=401,
                    detail="Неверный email или пароль",
                    headers={"WWW-Authenticate": "Bearer"},
                )
                
            access_token = create_access_token(data={"sub": str(company.id)})
            print(f"Успешный вход для компании {form_data.username}")
            return {"access_token": access_token, "token_type": "bearer"}
            
        finally:
            db.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Неожиданная ошибка при входе: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Внутренняя ошибка сервера: {str(e)}"
        )

@app.get("/profile")
async def get_company_profile(current_company: Company = Depends(get_current_company)):
    return {
        "id": current_company.id,
        "name": current_company.name,
        "description": current_company.description,
        "partners": [p.strip() for p in current_company.partners.split(',')],
        "icon_path": current_company.icon_path,
        "user_type": current_company.user_type,
        "email": current_company.email
    }

# Запуск приложения
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000) 