from sqlalchemy import Column, Integer, String, Text
from database import Base

class Company(Base):
    __tablename__ = 'companies'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=False)
    partners = Column(Text, nullable=False)
    icon_path = Column(String(200), nullable=False)
    user_type = Column(String(50), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String(200), nullable=False) 