import './App.css'
import { BrowserRouter, Route, Routes } from "react-router-dom";
import ProfileLayout from "./layouts/ProfileLayout.jsx";
import HomePage from "./pages/HomePage.jsx";
import BonusesPage from "./pages/BonusesPage/BonusesPage.jsx";
import RatingPage from "./pages/Rating/Rating.jsx";
import PartnersPage from "./pages/Partners/Partners.jsx";
import AchievementsPage from "./pages/Achievements/Achievements.jsx";
import BonusesAdmin from "./pages/Bonuses/Bonuses.jsx";
import DemoBonuses from './components/Demo/DemoBonuses';
import DemoPartners from './components/Demo/DemoPartners';
import { AuthProvider } from './context/AuthContext';
import PartnerVolunteers from './pages/PartnerVolunteers/PartnerVolunteers';
import AuthForm from './components/AuthForm.jsx';
import NotFoundPage from './pages/NotFoundPage/NotFoundPage';
import AdminLogin from './components/Admins/AdminLogin';
import AdminProfile from './components/Admins/AdminProfile';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage/>} />
          <Route path="/admin" element={<AdminLogin />} />
          <Route path="/admin/profile" element={<AdminProfile />} />
          <Route path="/auth" element={<AuthForm />} />
          <Route path="/profile" element={<ProfileLayout />}>
            <Route index element={<div>Профиль</div>} />
            <Route path="bonuses" element={<BonusesPage />} />
            <Route path="rating" element={<RatingPage />} />
            <Route path="partners" element={<PartnersPage />} />
            <Route path="achievements" element={<AchievementsPage />} />
            <Route path="manage-bonuses" element={<BonusesAdmin />} />
          </Route>
          <Route path="/demo/bonuses" element={<DemoBonuses />} />
          <Route path="/demo/partners" element={<DemoPartners />} />
          <Route path="/partner/:partnerId/volunteers" element={<PartnerVolunteers />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}

export default App;