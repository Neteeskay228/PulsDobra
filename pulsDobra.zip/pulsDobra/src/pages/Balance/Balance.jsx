import React, { useState } from 'react';
import styles from './Balance.module.css';
import CustomButton from '../../components/CustomButton/CustomButton';
import TransactionHistory from '../../components/TransactionHistory/TransactionHistory';
import denga from '../../images/profile/denga.svg';
import back1 from '../../images/Card/back1.svg';

const Balance = () => {
  const [transactions] = useState([
    {
      id: 1,
      title: 'Билет в театр',
      image: back1,
      amount: 150,
      type: 'purchase',
      date: '2024-03-15'
    },
    // Добавьте больше транзакций по необходимости
  ]);

  return (
    <div className={styles.balancePage}>
      <div className={styles.balanceSection}>
        <div className={styles.balanceCard}>
          <h2>Баланс баллов</h2>
          <div className={styles.balanceAmount}>
            <span>90</span>
            <img src={denga} alt="points" />
          </div>
        </div>
        
        <div className={styles.statsContainer}>
          <div className={styles.statCard}>
            <h3>Потрачено</h3>
            <div className={styles.statAmount}>
              <span>150</span>
              <img src={denga} alt="points" />
            </div>
          </div>
          <div className={styles.statCard}>
            <h3>Заработано</h3>
            <div className={styles.statAmount}>
              <span>240</span>
              <img src={denga} alt="points" />
            </div>
          </div>
        </div>
      </div>

      <div className={styles.historySection}>
        <div className={styles.historyHeader}>
          <h2>История</h2>
        </div>
        <div className={styles.historyButtons}>
            <CustomButton 
              text="Списания"
              style={{
                background: '#A035EB',
                color: 'white'
              }}
            />
            <CustomButton 
              text="Пополнения"
              style={{
                background: 'none',
                color: '#A035EB',
                cursor: 'not-allowed'
              }}
            />
          </div>

        <TransactionHistory transactions={transactions} />
      </div>
    </div>
  );
};

export default Balance; 