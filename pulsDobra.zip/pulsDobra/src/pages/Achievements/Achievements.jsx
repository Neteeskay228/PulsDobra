import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './Achievements.module.css';
import CustomButton from '../../components/CustomButton/CustomButton';
import cup from '../../images/Achieve/cup.svg';
import { getVolunteerProfile } from '../../api/volunteerService';
import { useAuth } from '../../context/AuthContext';

const Achievements = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAchievements = async () => {
      if (user.role === 'volunteer') {
        try {
          setLoading(true);
          const volunteerData = await getVolunteerProfile();
          
          // Convert achievements string to array and format it
          const achievementsArray = volunteerData.achievements
            ? volunteerData.achievements.split(',').map((achievement, index) => ({
                id: `achievement_${index + 1}`,
                title: achievement.trim(),
                icon: cup
              }))
            : [];
          
          setAchievements(achievementsArray);
        } catch (err) {
          console.error('Error fetching achievements:', err);
          setError('Не удалось загрузить достижения');
          // Fallback to demo data
          setAchievements([
            {
              id: 'achievement_001',
              title: 'Помощь в организации благотворительного забега',
              icon: cup
            }
          ]);
        } finally {
          setLoading(false);
        }
      } else {
        // For non-volunteers, show demo data
        setAchievements([
          {
            id: 'achievement_001',
            title: 'Помощь в организации благотворительного забега',
            icon: cup
          }
        ]);
        setLoading(false);
      }
    };

    fetchAchievements();
  }, [user]);

  const handleShowMore = () => {
    navigate('/profile/achievements');
  };

  if (loading) {
    return <div className={styles.loading}>Загрузка...</div>;
  }

  if (error) {
    return <div className={styles.error}>{error}</div>;
  }

  return (
    <div className={styles.achievementsContainer}>
      <h1 className={styles.title}>Достижения <span style={{color:'#B0B0B0'}}>{achievements.length}</span></h1>
      
      <div className={styles.achievementsList}>
        {achievements.map(achievement => (
          <div key={achievement.id} className={styles.achievementCard}>
            <div className={styles.trophyContainer}>
              <img src={achievement.icon} alt="Иконка достижения" className={styles.trophyIcon} />
            </div>
            <div className={styles.achievementDetails}>
              <h3 className={styles.achievementTitle}>{achievement.title}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Achievements; 