import React, { useState, useEffect } from 'react';
import styles from './Partners.module.css';
import CustomButton from '../../components/CustomButton/CustomButton';
import { useNavigate } from 'react-router-dom';

const Partners = () => {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        const response = await fetch('http://127.0.0.1:8000/companies');
        if (!response.ok) {
          throw new Error('Failed to fetch companies');
        }
        const data = await response.json();
        setCompanies(data);
      } catch (err) {
        setError(err.message);
        console.error('Error fetching companies:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCompanies();
  }, []);

  if (loading) {
    return <div className={styles.loading}>Загрузка...</div>;
  }

  if (error) {
    return <div className={styles.error}>Ошибка: {error}</div>;
  }

  return (
    <div className={styles.partnersContainer}>
      <h1 className={styles.title}>Наши партнеры</h1>
      <div className={styles.partnersList}>
        {companies.map((company) => (
          <div key={company.name} className={styles.partnerCard}>
            <div className={styles.partnerInfo}>
              <div className={styles.logoContainer}>
                <img 
                  src={`http://127.0.0.1:8000/${company.icon_path}`} 
                  alt={`Логотип ${company.name}`} 
                  className={styles.logo} 
                />
              </div>
              <div className={styles.partnerDetails}>
                <h2 className={styles.partnerName}>{company.name}</h2>
                <p className={styles.partnerDescription}>{company.description}</p>
              </div>
            </div>
            <div className={styles.partnerActions}>
              <CustomButton 
                text="Подробнее"
                style={{
                  background: '#A035EB',
                  color: 'white',
                  width: '120px',
                }}
                onClick={() => navigate('/404')}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Partners; 