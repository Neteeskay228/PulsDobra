import React from 'react';
import { Button, Typography, Container } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './NotFoundPage.css';
import NotFoundImage from '../../images/404.svg'; 

const NotFoundPage = () => {
  const navigate = useNavigate();

  return (
    <div className="notfound-root">
      <Container className="notfound-container" maxWidth="sm">
        <img src={NotFoundImage} alt="404" className="notfound-image" />
        <Typography variant="h5" className="notfound-message">
          Упс! Страница не найдена.
        </Typography>
        <Typography variant="body1" className="notfound-subtext">
          Возможно, она была удалена или вы ошиблись адресом.
        </Typography>
        <Button
          variant="contained"
          color="secondary"
          onClick={() => navigate('/')}
          className="notfound-button"
        >
          На главную
        </Button>
      </Container>
    </div>
  );
};

export default NotFoundPage;