import React from 'react';
import HomeHeader from "../components/Header/HomeHeader";
import CustomButton from '../components/CustomButton/CustomButton';
import style from '../styles/HomePage.module.css';
import { Link } from 'react-router-dom';

const HomePage = () => {
    return (
        <>
            <HomeHeader />
            <main className={style.homeMain}>
                <div className={style.container}>
                    <h1>Ресурсный центр поддержки добровольчества</h1>
                    <div className={style.btns}>
                        <Link to="/auth">
                            <CustomButton
                                text="Хочу помочь"
                                style={{ color: '#ffffff', backgroundColor: '#A035EB' }}
                            />
                        </Link>
                        <Link to="/register">
                            <CustomButton
                                text="Стать организатором"
                            />
                        </Link>
                    </div>
                </div>
            </main>
        </>
    );
};

export default HomePage;