import React, { useState, useEffect } from 'react';
import styles from './BonusesPage.module.css';
import back1 from '../../images/Card/back1.svg';
import back2 from '../../images/Card/back2.svg';
import logoBiz from '../../images/profile/logoBiz.svg';
import logoFSP from '../../images/profile/logoFSP.svg';
import Card from '../../components/Card';
import { getBonuses } from '../../api/bonusService';
import { useAuth } from '../../context/AuthContext';

const BonusesPage = () => {
  const [loading, setLoading] = useState(true);
  const [bonuses, setBonuses] = useState({
    top: [],
    middle: [],
    bottom: []
  });
  const { user } = useAuth();

  useEffect(() => {
    const fetchBonuses = async () => {
      setLoading(true);
      try {
        // Fetch bonuses from backend
        const backendBonuses = await getBonuses(user?.organization?.name || "Мой бизнес");
        console.log('Backend bonuses:', backendBonuses);
        
        // Organize bonuses by applicable_range
        const organizedBonuses = {
          top: [],
          middle: [],
          bottom: []
        };
        
        backendBonuses.forEach(bonus => {
          // Add mock data for visual display
          const bonusWithMockData = {
            id: bonus.id,
            name: bonus.name,
            description: `Бонус для ${bonus.applicable_range === 1 ? '1-50' : 
                          bonus.applicable_range === 2 ? '51-100' : '101-150'} места`,
            price: "1500",
            maxUses: 1,
            image: back1,
            companyName: user?.organization?.name || "Мой бизнес",
            expiryDate: "30 апреля 2025",
            orgLogo: user?.organization?.img || logoBiz,
            applicable_range: bonus.applicable_range
          };
          
          // Add to appropriate category
          if (bonus.applicable_range === 1) {
            organizedBonuses.top.push(bonusWithMockData);
          } else if (bonus.applicable_range === 2) {
            organizedBonuses.middle.push(bonusWithMockData);
          } else if (bonus.applicable_range === 3) {
            organizedBonuses.bottom.push(bonusWithMockData);
          }
        });
        
        setBonuses(organizedBonuses);
      } catch (error) {
        console.error('Error fetching bonuses:', error);
        // Fallback to demo data if API fails
        setBonuses({
          top: [
            {
              id: 1,
              image: back1,
              name: "Билет в театр",
              organizer: "Мой бизнес",
              expiryDate: "30 апреля 2025",
              price: "1500",
              description: "Получите билет в театр!",
              orgLogo: logoBiz
            }
          ],
          middle: [
            {
              id: 2,
              image: back2,
              name: "Скидка в ресторане",
              organizer: "ФСП ДНР",
              expiryDate: "31 мая 2025",
              price: "0",
              description: "Специальное предложение для волонтеров - скидка 20% на все меню.",
              conditions: "Действует на все позиции меню, кроме алкоголя.",
              howToGet: "Предъявить удостоверение волонтера официанту.",
              orgLogo: logoFSP
            }
          ],
          bottom: [
            {
              id: 3,
              image: back1,
              name: "Билет в театр",
              organizer: "Мой бизнес",
              expiryDate: "30 апреля 2025",
              price: "1500",
              description: "Получите билет в театр!",
              orgLogo: logoBiz
            }
          ]
        });
      } finally {
        setLoading(false);
      }
    };

    fetchBonuses();
  }, []);

  if (loading) {
    return <div className={styles.loading}>Загрузка...</div>;
  }

  return (
    <>
    <div className={styles.pageContainer}>
      <h2 className={styles.pageTitle}>Бонусы</h2>
      
      <section className={styles.bonusSection}> 
        <h2 className={styles.sectionTitle}>Бонусы для волонтеров с 1-50 местом</h2>
        <div className={styles.cardsContainer}>
          {bonuses.top.map(card => (
            <Card  
              key={card.id}
              card={card}
              isAdmin={false}
            />
          ))}
        </div>
       </section>

       <section className={styles.bonusSection}> 
        <h2 className={styles.sectionTitle}>Бонусы для волонтеров с 51-100 местом</h2>
        <div className={styles.cardsContainer}>
          {bonuses.middle.map(card => (
            <Card  
              key={card.id}
              card={card}
              isAdmin={false}
            />
          ))}
        </div>
       </section>

       <section className={styles.bonusSection}> 
        <h2 className={styles.sectionTitle}>Бонусы для волонтеров с 101-150 местом</h2>
        <div className={styles.cardsContainer}>
          {bonuses.bottom.map(card => (
            <Card  
              key={card.id}
              card={card}
              isAdmin={false}
            />
          ))}
        </div>
       </section>
      </div>
    </>
  );
};

export default BonusesPage; 