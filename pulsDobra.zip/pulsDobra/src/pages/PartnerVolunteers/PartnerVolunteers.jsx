import React, { useState, useEffect } from 'react';
import styles from './PartnerVolunteers.module.css';
import CustomButton from '../../components/CustomButton/CustomButton';
import cup from '../../images/Achieve/cup.svg';
import goldMedal from '../../images/Rating/r1.svg';
import silverMedal from '../../images/Rating/r2.svg';
import bronzeMedal from '../../images/Rating/r3.svg';
import denga from '../../images/profile/denga.svg';
import back1 from '../../images/Card/back1.svg';
const PartnerVolunteers = () => {
  const [volunteers, setVolunteers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [allVolunteers, setAllVolunteers] = useState([]);
  const [expandedVolunteer, setExpandedVolunteer] = useState(null);
  const [expandedSection, setExpandedSection] = useState(null); // 'achievements' or 'bonuses'

  // Загрузка всех волонтеров при монтировании компонента
  useEffect(() => {
    fetchAllVolunteers();
  }, []);

  // Функция для загрузки всех волонтеров с бэкенда
  const fetchAllVolunteers = async () => {
    setLoading(true);
    try {
      const response = await fetch('http://127.0.0.1:8000/listvolonter');
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      
      // Преобразуем данные в нужный формат
      const formattedVolunteers = data.map((volunteer, index) => ({
        id: volunteer.volunteer_id,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${volunteer.volunteer_id}`,
        rating: index + 1, // Рейтинг по порядку
        achievements: [
          { 
            id: 1, 
            title: volunteer.achievements, 
            image: cup 
          }
        ],
        bonuses: [
          { id: 1, title: 'Билет в театр', points: 500 },
          { id: 2, title: 'Скидка 20% в магазине', points: 300 }
        ]
      }));
      
      setAllVolunteers(formattedVolunteers);
      
      // Загружаем первую страницу
      const initialVolunteers = formattedVolunteers.slice(0, 10);
      setVolunteers(initialVolunteers);
      setHasMore(formattedVolunteers.length > 10);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching volunteers:', error);
      setLoading(false);
    }
  };

  // Функция для загрузки дополнительных волонтеров
  const loadMoreVolunteers = () => {
    if (loading || !hasMore) return;
    
    setLoading(true);
    try {
      const nextPage = currentPage + 1;
      const startIndex = (nextPage - 1) * 10;
      const endIndex = startIndex + 10;
      const newVolunteers = allVolunteers.slice(startIndex, endIndex);
      
      setVolunteers(prevVolunteers => [...prevVolunteers, ...newVolunteers]);
      setCurrentPage(nextPage);
      setHasMore(endIndex < allVolunteers.length);
      setLoading(false);
    } catch (error) {
      console.error('Error loading more volunteers:', error);
      setLoading(false);
    }
  };

  const handleExpand = (volunteerId, section) => {
    if (expandedVolunteer === volunteerId && expandedSection === section) {
      setExpandedVolunteer(null);
      setExpandedSection(null);
    } else {
      setExpandedVolunteer(volunteerId);
      setExpandedSection(section);
    }
  };

  // Получение стилей для волонтера в зависимости от его рейтинга
  const getUserStyle = (rating) => {
    switch (rating) {
      case 1:
        return styles.goldUser;
      case 2:
        return styles.silverUser;
      case 3:
        return styles.bronzeUser;
      default:
        return '';
    }
  };

  // Получение медали для топ-3 волонтеров
  const getMedal = (rating) => {
    switch (rating) {
      case 1:
        return <img src={goldMedal} alt="Gold Medal" className={styles.medal} />;
      case 2:
        return <img src={silverMedal} alt="Silver Medal" className={styles.medal} />;
      case 3:
        return <img src={bronzeMedal} alt="Bronze Medal" className={styles.medal} />;
      default:
        return <span className={styles.ratingNumber}>{rating}</span>;
    }
  };

  const renderAchievements = (achievements) => {
    if (!achievements || achievements.length === 0) {
      return (
        <div className={styles.expandedContent}>
          <h3>Достижения</h3>
          <p>У волонтера пока нет достижений</p>
        </div>
      );
    }

    return (
      <div className={styles.expandedContent}>
        <h3>Достижения</h3>
        <div className={styles.itemsList}>
          {achievements.map(achievement => (
            <div key={achievement.id} className={styles.itemCard}>
              <div className={styles.itemImage}>
                <img src={achievement.image} alt={achievement.title} />
              </div>
              <div className={styles.itemInfo}>
                <h4 className={styles.itemTitle}>{achievement.title}</h4>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderBonuses = (bonuses) => {
    if (!bonuses || bonuses.length === 0) {
      return (
        <div className={styles.expandedContent}>
          <h3>Бонусы</h3>
          <p>У волонтера пока нет бонусов</p>
        </div>
      );
    }

    return (
      <div className={styles.expandedContent}>
        <h3>Бонусы</h3>
        <div className={styles.itemsList}>
          {bonuses.map(bonus => (
            <div key={bonus.id} className={styles.itemCard}>
              <div className={styles.itemImage}>
                <img src={back1} alt={bonus.title} />
              </div>
              <div className={styles.itemInfo}>
                <h4 className={styles.itemTitle}>{bonus.title}</h4>
                <div className={styles.bonusAmount}>
                  <span>{bonus.points}</span>
                  <img src={denga} alt="points" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className={styles.partnerVolunteersPage}>
      <div className={styles.volunteersList}>
        {volunteers.map((volunteer) => (
          <div
            key={volunteer.id}
            className={`${styles.volunteerCard} ${getUserStyle(volunteer.rating)}`}
          >
            <div className={styles.volunteerInfo}>
              <div className={styles.avatar}>
                <img src={volunteer.avatar} alt={`Avatar ${volunteer.id}`} />
              </div>
              <span className={styles.volunteerId}>{volunteer.id}</span>
            </div>
            
            <div className={styles.volunteerActions}>
              <CustomButton 
                text="Достижения" 
                onClick={() => handleExpand(volunteer.id, 'achievements')}
                style={{
                  background: expandedVolunteer === volunteer.id && expandedSection === 'achievements' ? '#A035EB' : 'white',
                  color: expandedVolunteer === volunteer.id && expandedSection === 'achievements' ? 'white' : '#A035EB',
                  border: '1px solid #A035EB',
                  opacity: volunteer.achievements && volunteer.achievements.length > 0 ? 1 : 0.5
                }}
                disabled={!volunteer.achievements || volunteer.achievements.length === 0}
              />
              <CustomButton 
                text="Бонусы" 
                onClick={() => handleExpand(volunteer.id, 'bonuses')}
                style={{
                  background: expandedVolunteer === volunteer.id && expandedSection === 'bonuses' ? '#A035EB' : 'white',
                  color: expandedVolunteer === volunteer.id && expandedSection === 'bonuses' ? 'white' : '#A035EB',
                  border: '1px solid #A035EB',
                  opacity: volunteer.bonuses && volunteer.bonuses.length > 0 ? 1 : 0.5
                }}
                disabled={!volunteer.bonuses || volunteer.bonuses.length === 0}
              />
            </div>
            
            <div className={styles.ratingBadge}>
              {getMedal(volunteer.rating)}
            </div>
            
            {expandedVolunteer === volunteer.id && (
              <div className={styles.expandedSection}>
                {expandedSection === 'achievements' && renderAchievements(volunteer.achievements)}
                {expandedSection === 'bonuses' && renderBonuses(volunteer.bonuses)}
              </div>
            )}
          </div>
        ))}
      </div>
      {loading && <div className={styles.loading}>Загрузка...</div>}
      {!loading && hasMore && (
        <div className={styles.loadMoreContainer}>
          <CustomButton 
            text="Показать еще"
            style={{
              background: '#A035EB',
              color: 'white',
              width: '200px',
            }}
            onClick={loadMoreVolunteers}
          />
        </div>
      )}
    </div>
  );
};

export default PartnerVolunteers; 