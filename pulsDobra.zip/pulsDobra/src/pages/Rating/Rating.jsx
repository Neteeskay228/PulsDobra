import React, { useState, useEffect } from 'react';
import styles from './Rating.module.css';
import CustomButton from '../../components/CustomButton/CustomButton';
import goldMedal from '../../images/Rating/r1.svg';
import silverMedal from '../../images/Rating/r2.svg';
import bronzeMedal from '../../images/Rating/r3.svg';

const Rating = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [allUsers, setAllUsers] = useState([]);

  // Загрузка всех пользователей при монтировании компонента
  useEffect(() => {
    fetchAllUsers();
  }, []);

  // Функция для загрузки всех пользователей с бэкенда
  const fetchAllUsers = async () => {
    setLoading(true);
    try {
      const response = await fetch('http://127.0.0.1:8000/listvolonter');
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      
      // Преобразуем данные в нужный формат
      const formattedUsers = data.map((user, index) => ({
        id: user.volunteer_id,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.volunteer_id}`,
        rating: index + 1, // Рейтинг по порядку
      }));
      
      setAllUsers(formattedUsers);
      
      // Загружаем первую страницу
      const initialUsers = formattedUsers.slice(0, 10);
      setUsers(initialUsers);
      setHasMore(formattedUsers.length > 10);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching users:', error);
      setLoading(false);
    }
  };

  // Функция для загрузки дополнительных пользователей
  const loadMoreUsers = () => {
    if (loading || !hasMore) return;
    
    setLoading(true);
    try {
      const nextPage = currentPage + 1;
      const startIndex = (nextPage - 1) * 10;
      const endIndex = startIndex + 10;
      const newUsers = allUsers.slice(startIndex, endIndex);
      
      setUsers(prevUsers => [...prevUsers, ...newUsers]);
      setCurrentPage(nextPage);
      setHasMore(endIndex < allUsers.length);
      setLoading(false);
    } catch (error) {
      console.error('Error loading more users:', error);
      setLoading(false);
    }
  };

  // Получение стилей для пользователя в зависимости от его рейтинга
  const getUserStyle = (rating) => {
    switch (rating) {
      case 1:
        return styles.goldUser;
      case 2:
        return styles.silverUser;
      case 3:
        return styles.bronzeUser;
      default:
        return '';
    }
  };

  // Получение медали для топ-3 пользователей
  const getMedal = (rating) => {
    switch (rating) {
      case 1:
        return <img src={goldMedal} alt="Gold Medal" className={styles.medal} />;
      case 2:
        return <img src={silverMedal} alt="Silver Medal" className={styles.medal} />;
      case 3:
        return <img src={bronzeMedal} alt="Bronze Medal" className={styles.medal} />;
      default:
        return <span className={styles.ratingNumber}>{rating}</span>;
    }
  };

  return (
    <div className={styles.ratingContainer}>
      <h1 className={styles.title}>Рейтинг пользователей</h1>
      <div className={styles.usersList}>
        {users.map((user) => (
          <div
            key={user.id}
            className={`${styles.userItem} ${getUserStyle(user.rating)}`}
          >
            <div className={styles.userInfo}>
              <div className={styles.avatar}>
                <img src={user.avatar} alt={`Avatar ${user.id}`} />
              </div>
              <span className={styles.userId}>{user.id}</span>
            </div>
            <div className={styles.ratingBadge}>
              {getMedal(user.rating)}
            </div>
          </div>
        ))}
      </div>
      {loading && <div className={styles.loading}>Загрузка...</div>}
      {!loading && hasMore && (
        <div className={styles.loadMoreContainer}>
          <CustomButton 
            text="Показать еще"
            style={{
              background: '#A035EB',
              color: 'white',
              width: '200px',
            }}
            onClick={loadMoreUsers}
          />
        </div>
      )}
    </div>
  );
};

export default Rating; 