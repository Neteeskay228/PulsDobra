import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './Bonuses.module.css';
import CustomButton from '../../components/CustomButton/CustomButton';
import denga from '../../images/profile/denga.svg';
import back1 from '../../images/Card/back1.svg';
import back2 from '../../images/Card/back2.svg';
import logoBiz from '../../images/profile/logoBiz.svg';
import logoFSP from '../../images/profile/logoFSP.svg';
import Card from '../../components/Card';
import Modal from '../../components/Modal/Modal';
import { getBonuses, createBonus, updateBonus, deleteBonus } from '../../api/bonusService';

const BonusesAdmin = () => {
  const navigate = useNavigate();
  const [bonuses, setBonuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBonus, setEditingBonus] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    applicable_range: 1,
    organizer: '',
    // Mock data fields (not saved to backend)
    description: 'Описание бонуса',
    price: '150',
    maxUses: '1',
    image: back1,
    companyName: 'Мой бизнес',
    expiryDate: '30 апреля 2025',
    orgLogo: logoBiz
  });

  // Demo data for bonuses
  const demoBonuses = [
    { 
      id: 1, 
      name: 'Билет в театр', 
      description: 'Билет на любой спектакль в городском театре', 
      price: 150, 
      maxUses: 1, 
      image: back1,
      companyName: "Мой бизнес",
      expiryDate: "30 апреля 2025",
      orgLogo: logoBiz
    },
    { 
      id: 2, 
      name: 'Сертификат в книжный магазин', 
      description: 'Сертификат на покупку книг в магазине "Читай-город"', 
      price: 200, 
      maxUses: 2, 
      image: back2,
      companyName: "ФСП ДНР",
      expiryDate: "31 мая 2025",
      orgLogo: logoFSP
    },
    { 
      id: 3, 
      name: 'Билет в кино', 
      description: 'Билет на любой фильм в кинотеатре "КиноПарк"', 
      price: 100, 
      maxUses: 3, 
      image: back1,
      companyName: "Мой бизнес",
      expiryDate: "30 июня 2025",
      orgLogo: logoBiz
    },
    { 
      id: 4, 
      name: 'Скидка в кафе', 
      description: 'Скидка 20% на любой заказ в кафе "Уют"', 
      price: 50, 
      maxUses: 5, 
      image: back2,
      companyName: "ФСП ДНР",
      expiryDate: "31 июля 2025",
      orgLogo: logoFSP
    },
    { 
      id: 5, 
      name: 'Билет в музей', 
      description: 'Билет в любой музей города', 
      price: 120, 
      maxUses: 1, 
      image: back1,
      companyName: "Мой бизнес",
      expiryDate: "30 августа 2025",
      orgLogo: logoBiz
    }
  ];

  useEffect(() => {
    const fetchBonuses = async () => {
      setLoading(true);
      try {
        const backendBonuses = await getBonuses("Мой бизнес");
        console.log('Backend bonuses:', backendBonuses);
        
        const combinedBonuses = backendBonuses.map(bonus => ({
          id: bonus.id,
          name: bonus.name,
          description: `Бонус для ${bonus.applicable_range === 1 ? '1-50' : 
                        bonus.applicable_range === 2 ? '51-100' : '101-150'} места`,
          price: 150,
          maxUses: 1,
          image: back1,
          companyName: bonus.organizer,
          expiryDate: "30 апреля 2025",
          orgLogo: logoBiz,
          applicable_range: bonus.applicable_range
        }));

        console.log('Combined bonuses:', combinedBonuses);
        setBonuses(combinedBonuses);
      } catch (error) {
        console.error('Error fetching bonuses:', error);
        setBonuses(demoBonuses);
      } finally {
        setLoading(false);
      }
    };

    fetchBonuses();
  }, []);

  const handleOpenModal = (bonus = null) => {
    if (bonus) {
      setEditingBonus(bonus);
      setFormData({
        name: bonus.name,
        applicable_range: bonus.applicable_range,
        organizer: bonus.companyName,
        // Mock data fields
        description: 'Описание бонуса',
        price: '150',
        maxUses: '1',
        image: back1,
        companyName: bonus.companyName,
        expiryDate: '30 апреля 2025',
        orgLogo: logoBiz
      });
    } else {
      setEditingBonus(null);
      setFormData({
        name: '',
        applicable_range: 1,
        organizer: '',
        // Mock data fields
        description: 'Описание бонуса',
        price: '150',
        maxUses: '1',
        image: back1,
        companyName: 'Мой бизнес',
        expiryDate: '30 апреля 2025',
        orgLogo: logoBiz
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingBonus(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name) {
      alert('Пожалуйста, введите название бонуса');
      return;
    }

    try {
      if (editingBonus) {
        // Update existing bonus
        const updateData = {
          name: formData.name,
          applicable_range: formData.applicable_range,
          organizer: formData.organizer || formData.companyName
        };
        
        const updatedBonus = await updateBonus(editingBonus.id, updateData);
        console.log('Updated bonus:', updatedBonus);
        
        // Update local state
        setBonuses(prev => prev.map(bonus => 
          bonus.id === editingBonus.id 
            ? { 
                ...bonus, 
                name: updatedBonus.name,
                applicable_range: updatedBonus.applicable_range,
                // Keep mock data
                description: formData.description,
                price: parseInt(formData.price),  
                maxUses: parseInt(formData.maxUses),
                image: formData.image,
                companyName: formData.organizer || formData.companyName,
                expiryDate: formData.expiryDate,
                orgLogo: formData.orgLogo
              } 
            : bonus
        ));
      } else {
        // Create new bonus
        const newBonusData = {
          name: formData.name,
          applicable_range: formData.applicable_range,
          organizer: formData.organizer || formData.companyName
        };

        const createdBonus = await createBonus(newBonusData);
        console.log('Created bonus:', createdBonus);
        
        // Add to local state with mock data
        const newBonus = {
          id: createdBonus.id,
          name: createdBonus.name,
          description: `Бонус для ${createdBonus.applicable_range === 1 ? '1-50' : 
                        createdBonus.applicable_range === 2 ? '51-100' : '101-150'} места`,
          price: 150,
          maxUses: 1,
          image: back1,
          companyName: createdBonus.organizer,
          expiryDate: "30 апреля 2025",
          orgLogo: logoBiz,
          applicable_range: createdBonus.applicable_range
        };

        setBonuses(prev => [...prev, newBonus]);
      }
      
      handleCloseModal();
    } catch (error) {
      console.error('Error saving bonus:', error);
      alert('Произошла ошибка при сохранении бонуса');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Вы уверены, что хотите удалить этот бонус?')) {
      return;
    }
    
    try {
      await deleteBonus(id);
      setBonuses(prev => prev.filter(bonus => bonus.id !== id));
    } catch (error) {
      console.error('Error deleting bonus:', error);
      alert('Произошла ошибка при удалении бонуса');
    }
  };

  if (loading) {
    return <div className={styles.loading}>Загрузка...</div>;
  }

  return (
    <div className={styles.bonusesPage}>
      <div className={styles.header}>
        <h1 className={styles.pageTitle}>Управление бонусами</h1>
        <CustomButton 
          text="Добавить бонус" 
          onClick={() => handleOpenModal()}
          style={{
            background: '#A035EB',
            color: 'white'
          }}
        />
      </div>

      <div className={styles.bonusesGrid}>
        {bonuses.map(bonus => {
          console.log('Bonus object:', bonus);
          return (
            <div key={bonus.id} className={styles.bonusCardWrapper}>
              <Card 
                card={bonus}
                isAdmin={true}
                onEdit={() => handleOpenModal(bonus)}
                onDelete={() => handleDelete(bonus.id)}
              />
            </div>
          );
        })}
      </div>

      {isModalOpen && (
        <Modal onClose={handleCloseModal}>
          <div className={styles.modalContent}>
            <h2>{editingBonus ? 'Редактировать бонус' : 'Добавить бонус'}</h2>
            <form onSubmit={handleSubmit}>
              <div className={styles.formGroup}>
                <label htmlFor="name">Название</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Название бонуса"
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="applicable_range">Категория</label>
                <select
                  id="applicable_range"
                  name="applicable_range"
                  value={formData.applicable_range}
                  onChange={handleInputChange}
                  required
                  className={styles.selectInput}
                >
                  <option value={1}>1-50 места</option>
                  <option value={2}>51-100 места</option>
                  <option value={3}>101-150 места</option>
                </select>
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="organizer">Организатор</label>
                <input
                  type="text"
                  id="organizer"
                  name="organizer"
                  value={formData.organizer}
                  onChange={handleInputChange}
                  placeholder="Название организатора"
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="description">Описание</label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Описание бонуса"
                  rows="3"
                />
              </div>
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="price">Стоимость (баллы)</label>
                  <input
                    type="number"
                    id="price"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    placeholder="Стоимость"
                    min="1"
                  />
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="maxUses">Макс. использований</label>
                  <input
                    type="number"
                    id="maxUses"
                    name="maxUses"
                    value={formData.maxUses}
                    onChange={handleInputChange}
                    placeholder="Макс. использований"
                    min="1"
                  />
                </div>
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="companyName">Название организации</label>
                <input
                  type="text"
                  id="companyName"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleInputChange}
                  placeholder="Название организации"
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="expiryDate">Срок действия</label>
                <input
                  type="text"
                  id="expiryDate"
                  name="expiryDate"
                  value={formData.expiryDate}
                  onChange={handleInputChange}
                  placeholder="Срок действия"
                />
              </div>
              <div className={styles.modalActions}>
                <CustomButton 
                  text="Отмена" 
                  onClick={handleCloseModal}
                  style={{
                    background: 'white',
                    color: '#666',
                    border: '1px solid #ddd'
                  }}
                />
                <CustomButton 
                  text={editingBonus ? 'Сохранить' : 'Добавить'} 
                  type="submit"
                  style={{
                    background: '#A035EB',
                    color: 'white'
                  }}
                />
              </div>
            </form>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default BonusesAdmin; 