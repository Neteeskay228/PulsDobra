import logoBiz from '../images/profile/logoBiz.svg';
import logoFSP from '../images/profile/logoFSP.svg';

export const partners = [
  {
    id: 'partner_001',
    name: 'Мой бизнес',
    logo: logoBiz,
    description: 'Центр поддержки предпринимательства',
    link: 'https://мойбизнес.рф'
  },
  {
    id: 'partner_002',
    name: 'ФСП ДНР',
    logo: logoFSP,
    description: 'Фонд содействия предпринимательству ДНР',
    link: 'https://fspdnr.ru'
  },
  {
    id: 'partner_003',
    name: 'Бизнес-инкубатор',
    logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=business_incubator',
    description: 'Центр развития стартапов и малого бизнеса',
    link: 'https://business-incubator.ru'
  },
  {
    id: 'partner_004',
    name: 'Центр инноваций',
    logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=innovation_center',
    description: 'Поддержка инновационных проектов',
    link: 'https://innovation-center.ru'
  },
  {
    id: 'partner_005',
    name: 'Бизнес-союз',
    logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=business_union',
    description: 'Объединение предпринимателей региона',
    link: 'https://business-union.ru'
  }
]; 