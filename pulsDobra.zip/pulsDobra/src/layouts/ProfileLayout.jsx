import { Outlet, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Header from '../components/Header/Header';
import ProfileSidebar from '../components/ProfileSidebar';
import ProfileContent from '../components/ProfileContent/ProfileContent';
import styles from '../styles/ProfileLayout.module.css';
import { useAuth } from '../context/AuthContext';

const ProfileLayout = () => {
  const { user } = useAuth();
  const location = useLocation();
  const [showSidebar, setShowSidebar] = useState(true);

  // Check if we're on a sub-route (bonuses, rating, partners)
  useEffect(() => {
    const isSubRoute = location.pathname !== '/profile';
    setShowSidebar(!isSubRoute);
  }, [location]);

  return (
    <div className={styles.layout}>
      <Header user={user} />
      <div className={styles.content}>
        {showSidebar && <ProfileSidebar />}
        <main className={`${styles.main} ${!showSidebar ? styles.fullWidth : ''}`}>
          {location.pathname === '/profile' ? (
            <ProfileContent user={user} />
          ) : (
            <Outlet />
          )}
        </main>
      </div>
    </div>
  );
};

export default ProfileLayout; 