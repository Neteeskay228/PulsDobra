import React from 'react';
const Layout = () => {

    return (
        <div>
            {/* <Header/> */}
            <main>
                <h1>лялялял</h1>
            </main>
        </div>
    );
};

export default Layout;