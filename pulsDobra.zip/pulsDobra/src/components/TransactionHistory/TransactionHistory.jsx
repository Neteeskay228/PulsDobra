import React from 'react';
import styles from './TransactionHistory.module.css';
import denga from '../../images/profile/denga.svg';

const TransactionHistory = ({ transactions, isAdmin = false }) => {
  return (
    <div className={styles.historyContainer}>
      {transactions.map((transaction) => (
        <div key={transaction.id} className={styles.transactionCard}>
          <div className={styles.transactionImage}>
            <img src={transaction.image} alt={transaction.title} />
          </div>
          <div className={styles.transactionInfo}>
            <h3 className={styles.transactionTitle}>{transaction.title}</h3>
            <p className={styles.transactionType}>
              {isAdmin ? transaction.buyer : 'Покупка'}
            </p>
          </div>
          <div className={styles.transactionAmount}>
            <span className={styles.amount}>-{transaction.amount}</span>
            <img src={denga} alt="points" className={styles.pointsIcon} />
          </div>
        </div>
      ))}
    </div>
  );
};

export default TransactionHistory; 