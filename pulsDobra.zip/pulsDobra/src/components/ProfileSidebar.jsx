import React, { useState, useEffect } from 'react';
import styles from '../styles/ProfileSidebar.module.css';
import CustomButton from './CustomButton/CustomButton';
import denga from '../images/profile/denga.svg';
import rate from '../images/profile/chart-bar.svg'
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getVolunteerProfile } from '../api/volunteerService';

const ProfileSidebar = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [volunteerData, setVolunteerData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchVolunteerData = async () => {
      if (user.role === 'volunteer') {
        try {
          setLoading(true);
          const data = await getVolunteerProfile();
          setVolunteerData(data);
        } catch (err) {
          console.error('Error fetching volunteer data:', err);
          setError('Failed to load volunteer data');
        } finally {
          setLoading(false);
        }
      }
    };

    fetchVolunteerData();
  }, [user.role]);
  
  const getInitials = (fullName) => {
    if (!fullName) return '';
    const parts = fullName.split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`;
    }
    return fullName[0] || '';
  };

  const handleAchievementsClick = () => {
    if (window.location.pathname === '/profile') {
      const achievementsTab = document.querySelector('[data-tab="achievements"]');
      if (achievementsTab) {
        achievementsTab.click();
      }
    } else {
      navigate('/profile');
    }
  };

  if (loading && user.role === 'volunteer') {
    return (
      <div className={styles.sidebar}>
        <div className={styles.profileCard}>
          <div className={styles.loading}>Загрузка...</div>
        </div>
      </div>
    );
  }

  if (error && user.role === 'volunteer') {
    return (
      <div className={styles.sidebar}>
        <div className={styles.profileCard}>
          <div className={styles.error}>{error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.sidebar}>
      <div className={styles.profileCard}>
        <div className={styles.profileInfo}>
          {user.role === 'volunteer' ? (
            <div className={styles.avatar}>
              {volunteerData ? getInitials(volunteerData.full_name) : getInitials(user.firstName, user.lastName)}
            </div>
          ) : (
            <div className={styles.avatar}>
              <img className={styles.profileImage} src={user.organization.img} alt="" />
            </div>
          )}

          <div className={styles.profileInfoText}>
            {user.role === 'volunteer' ? (
              <>
                <h2 className={styles.name}>{volunteerData ? volunteerData.full_name : `${user.firstName} ${user.lastName}`}</h2>
                <p className={styles.id}>ID: {volunteerData ? volunteerData.volunteer_id : user.id}</p>
              </>
            ) : (
              <>
                <h2 className={styles.name}>{`${user.organization.name}`}</h2>
                <p className={styles.nameOrg}>{user.organization.organizer}</p>
              </>
            )}
          </div>
        </div>

        {user.role === 'volunteer' ? (
          <>
            <div className={styles.info}>
              <div className={styles.rating}>
                <img src={rate} style={{ width: '30px', height: '30px', marginRight: '8px' }} alt="" />
                {volunteerData ? `${volunteerData.id} место` : `${user.rating} место`}
              </div>
              <div className={styles.birthDate}> 
                <strong>Дата рождения: </strong> {volunteerData ? volunteerData.birth_date : user.birthDate}
              </div>
            </div>

            <div className={styles.buttons}>
              <CustomButton 
                text="90"
                style={{ width: '100%' }}
                icon={denga} 
              />
            </div>
          </>
        ) : (
          <>
            <p className={styles.description}>{user.organization.description}</p>
            {/* <div className={styles.buttons}>
              <CustomButton 
                text="Управление волонтерами"
                style={{
                  background: '#A035EB',
                  color: 'white',
                  width: '100%',
                }}
              />
              <CustomButton 
                text="Статистика"
                style={{ width: '100%' }}
              />
              <CustomButton 
                text="Настройки организации"
                style={{ width: '100%' }}
              />
            </div> */}
          </>
        )}
      </div>
    </div>
  );
};

export default ProfileSidebar; 