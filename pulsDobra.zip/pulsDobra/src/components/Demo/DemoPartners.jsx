import React from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './DemoPartners.module.css';
import CustomButton from '../CustomButton/CustomButton';
import { partners } from '../../data/partners';

const DemoPartners = () => {
  const navigate = useNavigate();
  const demoPartners = partners.slice(0, 3);

  const handleShowMore = () => {
    navigate('/profile/partners');
  };

  return (
    <div className={styles.demoContainer}>
      <div className={styles.header}>
        <h2 className={styles.title}>Наши партнеры</h2>
        <p onClick={handleShowMore} className={styles.showMore}>Показать еще</p>
      </div>
      
      <div className={styles.partnersContainer}>
        {demoPartners.map(partner => (
          <div key={partner.id} className={styles.partnerCard}>
            <div className={styles.partnerInfo}>
              <div className={styles.logoContainer}>
                <img src={partner.logo} alt={`Логотип ${partner.name}`} className={styles.logo} />
              </div>
              <div className={styles.partnerDetails}>
                <h3 className={styles.partnerName}>{partner.name}</h3>
                <p className={styles.partnerDescription}>{partner.description}</p>
              </div>
            </div>
            <div className={styles.partnerActions}>
              <CustomButton 
                text="Подробнее"
                style={{
                  background: '#A035EB',
                  color: 'white',
                  width: '120px',
                }}
                onClick={() => window.open(partner.link, '_blank')}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DemoPartners; 