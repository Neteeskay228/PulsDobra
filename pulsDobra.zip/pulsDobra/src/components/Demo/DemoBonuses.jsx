import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './DemoBonuses.module.css';
import Card from '../Card';
import CustomButton from '../CustomButton/CustomButton';
import back1 from '../../images/Card/back1.svg';
import back2 from '../../images/Card/back2.svg';
import logoBiz from '../../images/profile/logoBiz.svg';
import logoFSP from '../../images/profile/logoFSP.svg';
import { getBonuses } from '../../api/bonusService';
import { useAuth } from '../../context/AuthContext';

const DemoBonuses = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [bonuses, setBonuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBonuses = async () => {
      if (user.role === 'volunteer') {
        try {
          setLoading(true);
          // Fetch all bonuses
          const allBonuses = await getBonuses("Мой бизнес");
          
          // Determine which bonuses to show based on volunteer's place
          let applicableRange = 1; // Default to top range
          
          // If we have user.id, use it to determine the range
          if (user.id) {
            if (user.id > 100) {
              applicableRange = 3; // Bottom range (101-150)
            } else if (user.id > 50) {
              applicableRange = 2; // Middle range (51-100)
            } else {
              applicableRange = 1; // Top range (1-50)
            }
          }
          
          // Filter bonuses by applicable_range
          const filteredBonuses = allBonuses
            .filter(bonus => bonus.applicable_range === applicableRange)
            .map(bonus => ({
              id: bonus.id,
              name: bonus.name,
              description: `Бонус для ${applicableRange === 1 ? '1-50' : 
                            applicableRange === 2 ? '51-100' : '101-150'} места`,
              price: "1500",
              maxUses: 1,
              image: back1,
              companyName: bonus.organizer,
              expiryDate: "30 апреля 2025",
              orgLogo: logoBiz,
              applicable_range: bonus.applicable_range
            }));
          
          setBonuses(filteredBonuses);
        } catch (err) {
          console.error('Error fetching bonuses:', err);
          setError('Failed to load bonuses');
          // Fallback to demo data
          setBonuses([
            {
              id: 1,
              image: back1,
              name: "Билет в театр",
              companyName: "Мой бизнес",
              expiryDate: "30 апреля 2025",
              price: "1500",
              description: "Получите билет в театр!",
              orgLogo: logoBiz
            },
            {
              id: 2,
              image: back2,
              name: "Скидка в ресторане",
              companyName: "ФСП ДНР",
              expiryDate: "31 мая 2025",
              price: "0",
              description: "Специальное предложение для волонтеров - скидка 20% на все меню.",
              conditions: "Действует на все позиции меню, кроме алкоголя.",
              howToGet: "Предъявить удостоверение волонтера официанту.",
              orgLogo: logoFSP
            }
          ]);
        } finally {
          setLoading(false);
        }
      } else {
        // For non-volunteers, use demo data
        setBonuses([
    {
      id: 1,
      image: back1,
            name: "Билет в театр",
      companyName: "Мой бизнес",
      expiryDate: "30 апреля 2025",
      price: "1500",
      description: "Получите билет в театр!",
      orgLogo: logoBiz
    },
    {
      id: 2,
      image: back2,
            name: "Скидка в ресторане",
      companyName: "ФСП ДНР",
      expiryDate: "31 мая 2025",
      price: "0",
      description: "Специальное предложение для волонтеров - скидка 20% на все меню.",
      conditions: "Действует на все позиции меню, кроме алкоголя.",
      howToGet: "Предъявить удостоверение волонтера официанту.",
      orgLogo: logoFSP
    }
        ]);
        setLoading(false);
      }
    };

    fetchBonuses();
  }, [user]);

  const handleShowMore = () => {
    navigate('/profile/bonuses');
  };

  if (loading) {
    return (
      <div className={styles.demoContainer}>
        <div className={styles.header}>
          <h2 className={styles.title}>Доступные бонусы</h2>
        </div>
        <div className={styles.loading}>Загрузка...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.demoContainer}>
        <div className={styles.header}>
          <h2 className={styles.title}>Доступные бонусы</h2>
        </div>
        <div className={styles.error}>{error}</div>
      </div>
    );
  }

  return (
    <div className={styles.demoContainer}>
      <div className={styles.header}>
        <h2 className={styles.title}>Доступные бонусы</h2>
        <p onClick={handleShowMore} className={styles.showMore}>Показать еще </p> 
      </div>
      
      <div className={styles.cardsContainer}>
        {bonuses.map(card => (
          <Card 
            key={card.id}
            card={card}
            isAdmin={false}
          />
        ))}
      </div>
    </div>
  );
};

export default DemoBonuses; 