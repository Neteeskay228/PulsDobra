import React, { useState, useEffect } from 'react';
import DemoBonuses from '../Demo/DemoBonuses';
import DemoPartners from '../Demo/DemoPartners';
import Achievements from '../../pages/Achievements/Achievements';
import styles from './ProfileContent.module.css';
import CustomButton from '../CustomButton/CustomButton';
import Balance from '../../pages/Balance/Balance';
import PartnerVolunteers from '../../pages/PartnerVolunteers/PartnerVolunteers';
import BonusesAdmin from '../../pages/Bonuses/Bonuses';

const ProfileContent = ({ user }) => {
  const [activeTab, setActiveTab] = useState(user?.role === 'admin' ? 'volunteers' : 'overview');

  const renderVolunteerContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className={styles.overviewContent}>
            <DemoBonuses />
            <DemoPartners />
          </div>
        );
      case 'achievements':
        return <Achievements />;
      case 'balance':
        return <Balance />;
      default:
        return null;
    }
  };

  const renderAdminContent = () => {
    switch (activeTab) {
    //   case 'overview':
    //     return <div>Обзор организации</div>;
    //   case 'statistics':
    //     return <div>Статистика организации</div>;
      case 'volunteers':
        return <PartnerVolunteers />;
      case 'bonuses':
        return <BonusesAdmin />;
    //   case 'settings':
    //     return <div>Настройки организации</div>;
      default:
        return null;
    }
  };

  return (
    <div className={styles.content}>
      <div className={styles.tabs}>
        {user?.role === 'admin' ? (
          <>
            {/* <button
              className={`${styles.tab} ${activeTab === 'overview' ? styles.active : ''}`}
              onClick={() => setActiveTab('overview')}
            >
              Обзор
            </button>
            <button
              className={`${styles.tab} ${activeTab === 'statistics' ? styles.active : ''}`}
              onClick={() => setActiveTab('statistics')}
            >
              Статистика
            </button> */}
            <button
              className={`${styles.tab} ${activeTab === 'volunteers' ? styles.active : ''}`}
              onClick={() => setActiveTab('volunteers')}
            >
              Список волонтеров
            </button>
            <button
              className={`${styles.tab} ${activeTab === 'bonuses' ? styles.active : ''}`}
              onClick={() => setActiveTab('bonuses')}
            >
              Управление бонусами
            </button>
            {/* <button
              className={`${styles.tab} ${activeTab === 'settings' ? styles.active : ''}`}
              onClick={() => setActiveTab('settings')}
            >
              Настройки
            </button> */}
          </>
        ) : (
          <>
            <button
              className={`${styles.tab} ${activeTab === 'overview' ? styles.active : ''}`}
              onClick={() => setActiveTab('overview')}
            >
              Обзор
            </button>
            <button
              className={`${styles.tab} ${activeTab === 'achievements' ? styles.active : ''}`}
              onClick={() => setActiveTab('achievements')}
            >
              Достижения
            </button>
            <button
              className={`${styles.tab} ${activeTab === 'balance' ? styles.active : ''}`}
              onClick={() => setActiveTab('balance')}
            >
              Баланс
            </button>
          </>
        )}
      </div>
      <div className={styles.tabContent}>
        {user?.role === 'admin' ? renderAdminContent() : renderVolunteerContent()}
      </div>
    </div>
  );
};

export default ProfileContent; 