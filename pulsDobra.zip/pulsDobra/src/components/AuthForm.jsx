import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  TextField,
  Typography,
  Container,
  Paper,
  Tabs,
  Tab,
} from '@mui/material';
import { API_ENDPOINTS } from '../api/constants';
import VolunteerLogo from '../assets/volunteer_id.svg';
import { useAuth } from '../context/AuthContext';
import logoBiz from '../images/profile/logoBiz.svg';

const AuthForm = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [userType, setUserType] = useState('volonter');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setMessage('');

    try {
      // Выбираем URL в зависимости от типа пользователя и действия
      const url = userType === 'volonter' 
        ? (isLogin ? API_ENDPOINTS.VOLUNTEER_LOGIN : API_ENDPOINTS.VOLUNTEER_REGISTER)
        : (isLogin ? API_ENDPOINTS.COMPANY_LOGIN : API_ENDPOINTS.COMPANY_REGISTER);

      if (isLogin) {
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            username: event.target.email.value,
            password: event.target.password.value,
            grant_type: 'password',
            user_type: userType
          })
        });

        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.detail || 'Ошибка входа');
        }

        if (data.access_token) {
          localStorage.setItem('token', data.access_token);
          localStorage.setItem('user_type', userType);
          
          // Создаем объект пользователя
          const userData = {
            id: data.id || '1',
            firstName: data.first_name || 'Иван',
            lastName: data.last_name || 'Иванов',
            role: userType === 'volonter' ? 'volunteer' : 'admin',
            rating: data.rating || 42,
            birthDate: data.birth_date || '01.01.2000',
            organization: data.organization || {
              name: 'Мой бизнес',
              organizer: 'Иван Иванов Иванович',
              description: 'Описание организации',
              img: logoBiz
            }
          };
          
          // Сохраняем данные пользователя
          login(userData);
          
          // Переходим на страницу профиля
          navigate('/profile');
        }
      } else {
        if (userType === 'volonter') {
          // Для регистрации волонтера используем query parameters
          const params = new URLSearchParams({
            inn: parseInt(event.target.inn.value, 10),
            email: event.target.email.value,
            password: event.target.password.value
          });

          const response = await fetch(`${url}?${params}`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json'
            },
            credentials: 'include'
          });

          const data = await response.json();
          
          if (!response.ok) {
            throw new Error(data.detail || 'Ошибка регистрации');
          }

          setMessage('Успешная регистрация: ' + data.message);
        } else {
          // Для регистрации организации используем FormData
          const formData = new FormData();
          formData.append('name', event.target.name.value);
          formData.append('description', event.target.description.value);
          formData.append('partners', event.target.partners.value);
          formData.append('icon_png', event.target.icon_png.files[0]);
          formData.append('email', event.target.email.value);
          formData.append('password', event.target.password.value);

          const response = await fetch(url, {
            method: 'POST',
            headers: {
              'accept': 'application/json'
            },
            body: formData
          });

          const data = await response.json();
          
          if (!response.ok) {
            throw new Error(data.detail || 'Ошибка регистрации');
          }

          setMessage('Успешная регистрация организации: ' + data.message);
        }
      }
    } catch (error) {
      console.error('Ошибка:', error);
      setError(error.message);
    }
  };

  const volunteerLoginFields = (
    <>
      <TextField
        margin="normal"
        required
        fullWidth
        id="email"
        label="Почта"
        name="email"
        autoComplete="email"
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="password"
        label="Пароль"
        type="password"
        id="password"
      />
    </>
  );

  const volunteerRegisterFields = (
    <>
      <TextField
        margin="normal"
        required
        fullWidth
        name="email"
        label="Почта"
        type="email"
        id="email"
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="password"
        label="Пароль"
        type="password"
        id="password"
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="inn"
        label="ИНН"
        id="inn"
        type="number"
      />
    </>
  );

  const companyRegisterFields = (
    <>
      <TextField
        margin="normal"
        required
        fullWidth
        name="email"
        label="Почта"
        type="email"
        id="email"
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="password"
        label="Пароль"
        type="password"
        id="password"
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="name"
        label="Название организации"
        id="name"
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="description"
        label="Описание"
        id="description"
        multiline
        rows={3}
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="partners"
        label="Партнеры (через запятую)"
        id="partners"
      />
      <input
        accept="image/png"
        id="icon_png"
        name="icon_png"
        type="file"
        required
        style={{ marginTop: '16px', marginBottom: '8px' }}
      />
      <Typography variant="caption" display="block" gutterBottom>
        Загрузите логотип организации (PNG)
      </Typography>
    </>
  );

  return (
    <Container component="main" maxWidth="xs" sx={{ 
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'transparent'
    }}>
      <Paper elevation={3} sx={{ p: 4, width: '100%', background: 'white' }}>
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
          <img src={VolunteerLogo} alt="Volunteer Logo" style={{ height: '64px', marginBottom: '16px' }} />
          
          <Typography component="h1" variant="h5">
            {isLogin ? 'Вход' : 'Регистрация'}
          </Typography>

          <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3, width: '100%' }}>
            <Tabs
              value={userType}
              onChange={(e, newValue) => setUserType(newValue)}
              variant="fullWidth"
              sx={{ mb: 3 }}
              TabIndicatorProps={{
                style: {
                    backgroundColor: '#8C2BCC',
                },
            }}
            >
              <Tab sx={{
                            color: '#8C2BCC',
                            '&.Mui-selected': {
                                color: '#6e22a1',
                            },
                        }} value="volonter" label="Волонтер" />
              <Tab sx={{
                            color: '#8C2BCC',
                            '&.Mui-selected': {
                                color: '#6e22a1',
                            },
                        }} value="organizator" label="Организатор" />
            </Tabs>

            {userType === 'volonter' 
              ? (isLogin ? volunteerLoginFields : volunteerRegisterFields)
              : (isLogin ? volunteerLoginFields : companyRegisterFields)
            }

            {error && (
              <Typography color="error" sx={{ mt: 2 }}>
                {error}
              </Typography>
            )}

            {message && (
              <Typography color="success" sx={{ mt: 2 }}>
                {message}
              </Typography>
            )}

            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ 
                mt: 3, 
                mb: 2, 
                backgroundColor: '#A035EB',
                '&:hover': {
                  backgroundColor: '#8C2BCC', // немного темнее для hover-эффекта
                }
              }}
            >
              {isLogin ? 'Войти' : 'Зарегистрироваться'}
            </Button>

            <Button
              fullWidth
              variant="text"
              onClick={() => setIsLogin(!isLogin)}
              sx={{ 
                mt: 3, 
                mb: 2, 
                color: '#A035EB',
              }}
            >
              {isLogin ? 'Нет аккаунта? Зарегистрироваться' : 'Уже есть аккаунт? Войти'}
            </Button>
          </Box>
        </Box>
      </Paper>
    </Container>
  );
};

export default AuthForm; 