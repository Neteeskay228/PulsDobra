
import { Link } from 'react-router-dom';
import styles from './Header.module.css';
import logout from '../../images/Header/logout.svg';
import pulse from '../../images/Header/pulse.svg';

const Header = ({ user }) => {
    const getInitials = (firstName, lastName) => {
        return `${firstName[0]}${lastName[0]}`;
    };

    return (
        <header className={styles.header}>
            <div className={styles.logo}>
                <Link to="/"><img src={pulse} alt="pulse" /></Link>
            </div>

            <nav className={styles.nav}>
                <Link to="/profile/bonuses" className={styles.navItem}>Бонусы</Link>
                <Link to="/profile/rating" className={styles.navItem}>Рейтинг</Link>
                <Link to="/profile/partners" className={styles.navItem}>Партнеры</Link>
            </nav>

            <div className={styles.profileMenu}>
                <Link to="/profile">
                    <div className={styles.avatar}>
                        {getInitials(user.firstName, user.lastName)}
                    </div>
                </Link>

                <Link to="/">
                        <img style={{ width: '35px', height: '35px' }} 
                        src={logout} alt="logout" />
                </Link>
            </div>
        </header>
    );
};

export default Header; 