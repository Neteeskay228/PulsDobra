// import { Link } from 'react-router-dom';
// import styles from './Header.module.css';

// const HomeHeader = () => {
//   return (
//     <header className={styles.header}>
//       <div className={styles.logo}>
//         <Link to="/">PULS</Link>
//       </div>

//       <nav className={styles.nav}>
//         <Link to="/about" className={styles.navItem}>О нас</Link>
//         <Link to="/events" className={styles.navItem}>Мероприятия</Link>
//         <Link to="/contacts" className={styles.navItem}>Контакты</Link>
//       </nav>

//       <div className={styles.authButtons}>
//         <Link to="/login" className={styles.loginButton}>Войти</Link>
//         <Link to="/register" className={styles.registerButton}>Регистрация</Link>
//       </div>
//     </header>
//   );
// };

// export default HomeHeader; 


import React from 'react';
import styles from './Header.module.css';
import CustomButton from '../CustomButton/CustomButton';
import PERS from '../../images/Header/PERS.svg';
import { Link } from 'react-router-dom';
import pulse from '../../images/Header/pulse.svg';

const HomeHeader = () => {
    return (
        <header className={styles.header}>
            <div className={styles.logo}>
                <Link to="/"><img src={pulse} alt="pulse" /></Link>
            </div>

            <div className={styles.authButtons}>
                <Link to="/auth">
                    <CustomButton
                        text="Войти"
                        icon={PERS}
                        style={{ color: '#393837', border: 'none' }}
                    />
                </Link>
                <Link to="/auth">
                    <CustomButton
                        text="Зарегистрироваться"
                    />
                </Link>
            </div>
        </header>
    );
};

export default HomeHeader;