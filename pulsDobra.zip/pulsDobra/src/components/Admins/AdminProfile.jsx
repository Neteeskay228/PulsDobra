import React, { useState, useEffect } from 'react';
import {
    Box,
    Container,
    Typography,
    Paper,
    AppBar,
    Toolbar,
    IconButton,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Tabs,
    Tab,
    CircularProgress,
    Alert,
    TextField,
    Button,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import LogoutIcon from '@mui/icons-material/Logout';
import { API_ENDPOINTS } from '../../api/constants';
import pulse from '../../images/Header/pulse.svg';

const emailRegex = /^\S+@\S+\.\S+$/;

const AdminProfile = () => {
    const navigate = useNavigate();

    const [tabValue, setTabValue] = useState(0);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const [volunteers, setVolunteers] = useState([]);
    const [volErrors, setVolErrors] = useState([]);                // ошибки для волонтёров

    const [companies, setCompanies] = useState([]);
    const [compErrors, setCompErrors] = useState([]);              // ошибки для компаний

    const [logs, setLogs] = useState('');

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        setLoading(true);
        setError('');
        try {
            const token = localStorage.getItem('token');
            if (!token) throw new Error('Не найден токен авторизации');

            const [volRes, compRes, logRes] = await Promise.all([
                fetch(API_ENDPOINTS.ADMIN_LIST, {
                    headers: { Authorization: token, Accept: 'application/json' },
                }),
                fetch(API_ENDPOINTS.COMPANY_LIST, {
                    headers: { Authorization: token, Accept: 'application/json' },
                }),
                fetch(API_ENDPOINTS.LOGS, {
                    headers: { Authorization: token, Accept: 'text/html' },
                }),
            ]);

            if (!volRes.ok || !compRes.ok || !logRes.ok) {
                throw new Error('Ошибка загрузки данных');
            }

            const [volData, compData, logText] = await Promise.all([
                volRes.json(),
                compRes.json(),
                logRes.text(),
            ]);

            setVolunteers(volData);
            // инициализируем пустые ошибки
            setVolErrors(volData.map(() => ({ full_name: '', email: '' })));

            setCompanies(compData);
            setCompErrors(compData.map(() => ({ name: '', email: '' })));

            setLogs(logText);
        } catch (err) {
            console.error(err);
            setError(err.message);
            if (err.message.includes('401')) handleLogout();
        } finally {
            setLoading(false);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user_type');
        navigate('/', { replace: true });
    };

    const handleTabChange = (_, newVal) => {
        setTabValue(newVal);
    };

    const validateVolunteerField = (idx, field, value) => {
        const errs = [...volErrors];
        if (field === 'full_name') {
            errs[idx].full_name = value.trim() === '' ? 'Обязательное поле' : '';
        } else if (field === 'email') {
            if (value.trim() === '') {
                errs[idx].email = 'Обязательное поле';
            } else if (!emailRegex.test(value.trim())) {
                errs[idx].email = 'Неправильный формат email';
            } else {
                errs[idx].email = '';
            }
        }
        setVolErrors(errs);
    };

    const validateCompanyField = (idx, field, value) => {
        const errs = [...compErrors];
        if (field === 'name') {
            errs[idx].name = value.trim() === '' ? 'Обязательное поле' : '';
        } else if (field === 'email') {
            if (value.trim() === '') {
                errs[idx].email = 'Обязательное поле';
            } else if (!emailRegex.test(value.trim())) {
                errs[idx].email = 'Неправильный формат email';
            } else {
                errs[idx].email = '';
            }
        }
        setCompErrors(errs);
    };

    const handleSaveVolunteer = async (item, idx) => {
        // проверяем ошибки перед отправкой
        if (volErrors[idx].full_name || volErrors[idx].email) return;
        try {
            const token = localStorage.getItem('token');
            const formData = new FormData();
            formData.append('user_id', item.id);
            formData.append('name', item.full_name);
            formData.append('email', item.email);

            const res = await fetch(API_ENDPOINTS.EDIT_USER, {
                method: 'POST',
                headers: { Authorization: token },
                body: formData,
            });
            if (!res.ok) throw new Error('Ошибка при сохранении волонтёра');
            const { user } = await res.json();

            const upd = [...volunteers];
            upd[idx] = { ...upd[idx], full_name: user.name, email: user.email };
            setVolunteers(upd);
        } catch (err) {
            console.error(err);
            setError(err.message);
        }
    };

    const handleSaveCompany = async (item, idx) => {
        if (compErrors[idx].name || compErrors[idx].email) return;
        try {
            const token = localStorage.getItem('token');
            const formData = new FormData();
            formData.append('company_id', item.id);
            formData.append('name', item.name);
            formData.append('email', item.email);
            formData.append('description', item.description || '');
            formData.append('partners', (item.partners || []).join(','));

            const res = await fetch(API_ENDPOINTS.EDIT_COMPANY, {
                method: 'POST',
                headers: { Authorization: token },
                body: formData,
            });
            if (!res.ok) throw new Error('Ошибка при сохранении организации');
            const { company } = await res.json();

            const upd = [...companies];
            upd[idx] = {
                ...upd[idx],
                name: company.name,
                email: company.email,
                description: company.description,
                partners: company.partners,
            };
            setCompanies(upd);
        } catch (err) {
            console.error(err);
            setError(err.message);
        }
    };

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
                <CircularProgress />
            </Box>
        );
    }

    return (
        <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
            <AppBar position="static">
                <Toolbar sx={{ justifyContent: 'space-between', backgroundColor: '#ffffff' }}>
                <img src={pulse} alt="pulse" />
                    <Typography variant="h6" sx={{ color: '#A035EB' }}x>Панель администратора</Typography>
                    <IconButton color="#A035EB" onClick={handleLogout}>
                        <LogoutIcon sx={{ color: '#A035EB' }} />
                    </IconButton>
                </Toolbar>
            </AppBar>

            <Container maxWidth="lg" sx={{ mt: 4 }}>
                {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

                <Paper sx={{ mb: 2 }}>
                    <Tabs
                        value={tabValue}
                        onChange={handleTabChange}
                        centered
                        sx={{ borderBottom: 1, borderColor: 'divider' }}
                        TabIndicatorProps={{
                            style: {
                                backgroundColor: '#8C2BCC',
                            },
                        }}
                    >
                        <Tab sx={{
                            color: '#8C2BCC',
                            '&.Mui-selected': {
                                color: '#6e22a1',
                            },
                        }} label="Волонтёры" />
                        <Tab sx={{
                            color: '#8C2BCC',
                            '&.Mui-selected': {
                                color: '#6e22a1',
                            },
                        }} label="Организации" />
                        <Tab sx={{
                            color: '#8C2BCC',
                            '&.Mui-selected': {
                                color: '#6e22a1',
                            },
                        }} label="Логи" />
                    </Tabs>
                </Paper>

                {tabValue < 2 ? (
                    <TableContainer component={Paper}>
                        <Table>
                            <TableHead>
                                {tabValue === 0 ? (
                                    <TableRow>
                                        <TableCell>ID</TableCell>
                                        <TableCell>Имя</TableCell>
                                        <TableCell>Email</TableCell>
                                        <TableCell>ИНН</TableCell>
                                        <TableCell>Код волонтёра</TableCell>
                                        <TableCell>Дата регистрации</TableCell>
                                        <TableCell>Действие</TableCell>
                                    </TableRow>
                                ) : (
                                    <TableRow>
                                        <TableCell>ID</TableCell>
                                        <TableCell>Название</TableCell>
                                        <TableCell>Email</TableCell>
                                        <TableCell>Описание</TableCell>
                                        <TableCell>Партнёры</TableCell>
                                        <TableCell>Действие</TableCell>
                                    </TableRow>
                                )}
                            </TableHead>
                            <TableBody>
                                {(tabValue === 0 ? volunteers : companies).map((item, idx) => (
                                    <TableRow key={item.id ?? idx}>
                                        {tabValue === 0 ? (
                                            <>
                                                <TableCell>{item.id}</TableCell>
                                                <TableCell>
                                                    <TextField
                                                        variant="outlined"
                                                        size="small"
                                                        error={Boolean(volErrors[idx]?.full_name)}
                                                        helperText={volErrors[idx]?.full_name}
                                                        value={item.full_name || ''}
                                                        onChange={e => {
                                                            const value = e.target.value;
                                                            const upd = [...volunteers];
                                                            upd[idx].full_name = value;
                                                            setVolunteers(upd);
                                                            validateVolunteerField(idx, 'full_name', value);
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        variant="outlined"
                                                        size="small"
                                                        error={Boolean(volErrors[idx]?.email)}
                                                        helperText={volErrors[idx]?.email}
                                                        value={item.email || ''}
                                                        onChange={e => {
                                                            const value = e.target.value;
                                                            const upd = [...volunteers];
                                                            upd[idx].email = value;
                                                            setVolunteers(upd);
                                                            validateVolunteerField(idx, 'email', value);
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>{item.inn || '—'}</TableCell>
                                                <TableCell>{item.volunteer_id || '—'}</TableCell>
                                                <TableCell>{item.birth_date || '—'}</TableCell>
                                                <TableCell>
                                                    <Button
                                                        variant="contained"
                                                        size="small"
                                                        disabled={!!volErrors[idx]?.full_name || !!volErrors[idx]?.email}
                                                        onClick={() => handleSaveVolunteer(item, idx)}
                                                        style={{ backgroundColor: '#A035EB', '&:hover': { backgroundColor: '#8C2BCC' } }}
                                                    >
                                                        Сохранить
                                                    </Button>
                                                </TableCell>
                                            </>
                                        ) : (
                                            <>
                                                <TableCell>{item.id}</TableCell>
                                                <TableCell>
                                                    <TextField
                                                        variant="outlined"
                                                        size="small"
                                                        error={Boolean(compErrors[idx]?.name)}
                                                        helperText={compErrors[idx]?.name}
                                                        value={item.name || ''}
                                                        onChange={e => {
                                                            const value = e.target.value;
                                                            const upd = [...companies];
                                                            upd[idx].name = value;
                                                            setCompanies(upd);
                                                            validateCompanyField(idx, 'name', value);
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        variant="outlined"
                                                        size="small"
                                                        error={Boolean(compErrors[idx]?.email)}
                                                        helperText={compErrors[idx]?.email}
                                                        value={item.email || ''}
                                                        onChange={e => {
                                                            const value = e.target.value;
                                                            const upd = [...companies];
                                                            upd[idx].email = value;
                                                            setCompanies(upd);
                                                            validateCompanyField(idx, 'email', value);
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        variant="outlined"
                                                        size="small"
                                                        value={item.description || ''}
                                                        onChange={e => {
                                                            const upd = [...companies];
                                                            upd[idx].description = e.target.value;
                                                            setCompanies(upd);
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        variant="outlined"
                                                        size="small"
                                                        value={(item.partners || []).join(',')}
                                                        onChange={e => {
                                                            const upd = [...companies];
                                                            upd[idx].partners = e.target.value
                                                                .split(',')
                                                                .map(s => s.trim());
                                                            setCompanies(upd);
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <Button
                                                        variant="contained"
                                                        size="small"
                                                        disabled={!!compErrors[idx]?.name || !!compErrors[idx]?.email}
                                                        onClick={() => handleSaveCompany(item, idx)}
                                                        style={{ backgroundColor: '#A035EB', '&:hover': { backgroundColor: '#8C2BCC' } }}
                                                    >
                                                        Сохранить
                                                    </Button>
                                                </TableCell>
                                            </>
                                        )}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                ) : (
                    <Paper sx={{ p: 2, whiteSpace: 'pre-wrap', fontFamily: 'monospace' }}>
                        <div dangerouslySetInnerHTML={{ __html: logs }} />
                    </Paper>
                )}
            </Container>
        </Box>
    );
};

export default AdminProfile;
