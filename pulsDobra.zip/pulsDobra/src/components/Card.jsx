import React, { useState } from 'react';
import styles from '../styles/Card.module.css';
import companyIcon from '../images/Card/company.svg';
import calendarIcon from '../images/Card/calendar.svg';
import moneyIcon from '../images/profile/denga.svg';
import CustomButton from './CustomButton/CustomButton';
import Modal from './Modal';

const Card = ({ card, isAdmin, onEdit, onDelete }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleCardClick = () => {
    setIsModalOpen(true);
  };

  return (
    <>
      <div className={styles.card} onClick={handleCardClick}>
        <img 
          src={card.image} 
          alt={card.name} 
          className={styles.cardImage}
        />
        <div className={styles.cardContent}>
          <div className={styles.infoRow}>
            <img src={companyIcon} alt="Company" />
            <span className={styles.organizer}>{card.companyName}</span>
          </div>
          <div className={styles.infoRow}>
            <span className={styles.title}>{card.name}</span>
          </div>
          <div className={styles.infoRow}>
            <img src={calendarIcon} alt="Date" />
            <span className={styles.date}>До {card.expiryDate}</span>
          </div>
          <div className={styles.infoRowPrice}>
            <img src={moneyIcon} alt="Price" />
            <span className={styles.price}>{card.price}</span>
          </div>
          
          {isAdmin && (
            <div className={styles.adminButtons}>
              <CustomButton 
                text="Редактировать"
                style={{
                  background: '#ffffff',
                  color: '#A035EB',
                  width: '100%',
                  border: '1px solid #A035EB',
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(card);
                }}
              />
              <CustomButton 
                text="Удалить"
                style={{
                  background: '#ffffff',
                  color: '#ff4444',
                  border: '1px solid #ff4444',
                  width: '100%',
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(card.id);
                }}
              />
            </div>
          )}
        </div>
      </div>

      <Modal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        card={card}
      />
    </>
  );
};

export default Card; 