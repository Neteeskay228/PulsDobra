import React from 'react';
import styles from '../styles/Modal.module.css';
import CustomButton from './CustomButton/CustomButton';
import calendarIcon from '../images/Card/calendar.svg';
import { useAuth } from '../context/AuthContext';
import { API_ENDPOINTS } from '../api/constants';

const Modal = ({ isOpen, onClose, card }) => {
  const { user } = useAuth();

  if (!isOpen) return null;

  const handleModalClose = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleDownload = async () => {
    const query = new URLSearchParams({
      bonus_company: card.companyName,
      bonus_name: card.name,
      id: user.id,
    });

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`${API_ENDPOINTS.GENERATE_PDF}?${query.toString()}`, {
        method: "GET",
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/pdf'
        }
      });

      if (!response.ok) {
        throw new Error("Ошибка при получении PDF");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "bonus.pdf");
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Ошибка при загрузке PDF:", error);
      alert("Произошла ошибка при скачивании сертификата");
    }
  };

  return (
    <div className={styles.modal} onClick={handleModalClose}>
      <div className={styles.modalContent}>
        <button className={styles.closeButton} onClick={onClose}>×</button>
        
        <img 
          src={card.image} 
          alt={card.title} 
          className={styles.modalImage}
        />
        
        <div className={styles.modalInfo}>
          <div className={styles.infoRow}>
            <img src={calendarIcon} alt="Date" />
            <span className={styles.date}>До {card.expiryDate}</span>
          </div>
          
          <h2 className={styles.title}>{card.name}</h2>
          <p className={styles.description}>{card.description}</p>
          
          <div className={styles.infoBoxContainer}>
            <div className={styles.infoBox}>
              <div className={styles.infoBoxTitle}>Спишется</div>
              <div className={styles.infoBoxContent}>{card.price}</div>
            </div>
          
            <div className={styles.infoBox}>
                <div className={styles.infoBoxTitle}>Можно получить</div>
                <div className={styles.infoBoxContent}>1 раз</div>
            </div>
          </div>

          <div className={styles.organizationInfo}>
            <img 
              src={card.orgLogo} 
              alt={card.companyName} 
              className={styles.orgLogo}
            />
            <span className={styles.organizer}>{card.companyName}</span>
          </div>

          <CustomButton 
            text="Получить"
            style={{
              background: '#A035EB',
              color: 'white',
              width: '100%',
            }}
            className={styles.getButton}
            onClick={handleDownload}
          />
        </div>
      </div>
    </div>
  );
};

export default Modal; 