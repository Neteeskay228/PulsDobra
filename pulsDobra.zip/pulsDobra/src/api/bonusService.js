import axios from 'axios';

const API_URL = 'http://127.0.0.1:8000';

export const getBonuses = async (organizer) => {
  try {
    const response = await axios.get(`${API_URL}/bonuses/`, {
      params: {
        organizer: organizer
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching bonuses:', error);
    throw error;
  }
};

export const createBonus = async (bonusData) => {
  try {
    const response = await axios.post(`${API_URL}/bonuses/`, {
      name: bonusData.name,
      applicable_range: bonusData.applicable_range,
      organizer: bonusData.organizer
    });
    return response.data;
  } catch (error) {
    console.error('Error creating bonus:', error);
    throw error;
  }
};

export const updateBonus = async (bonusId, bonusData) => {
  try {
    const response = await axios.patch(`${API_URL}/bonuses/${bonusId}/`, {
      name: bonusData.name,
      applicable_range: bonusData.applicable_range,
      organizer: bonusData.organizer
    });
    return response.data;
  } catch (error) {
    console.error('Error updating bonus:', error);
    throw error;
  }
};

export const deleteBonus = async (bonusId) => {
  try {
    await axios.delete(`${API_URL}/bonuses/${bonusId}/`);
  } catch (error) {
    console.error('Error deleting bonus:', error);
    throw error;
  }
}; 