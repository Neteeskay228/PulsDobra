const API_URL = 'http://127.0.0.1:8000';

export const getVolunteerProfile = async () => {
  try {
    const response = await fetch(`${API_URL}/volonter/profile`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch volunteer profile');
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching volunteer profile:', error);
    throw error;
  }
}; 