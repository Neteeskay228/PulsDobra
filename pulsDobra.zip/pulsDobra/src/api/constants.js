export const API_BASE_URL = 'http://localhost:8000';

export const API_ENDPOINTS = {
  VOLUNTEER_LOGIN: `${API_BASE_URL}/volonter/login`,
  VOLUNTEER_REGISTER: `${API_BASE_URL}/volonter/register`,
  VOLUNTEER_PROFILE: `${API_BASE_URL}/volonter/profile`,
  COMPANY_LOGIN: `${API_BASE_URL}/company/login`,
  COMPANY_REGISTER: `${API_BASE_URL}/company/register`,
  COMPANY_PROFILE: `${API_BASE_URL}/company/profile`,
  ADMIN_LOGIN: `${API_BASE_URL}/admin/login`,
  ADMIN_LIST: `${API_BASE_URL}/adminlistvolonter`,
  COMPANY_LIST: `${API_BASE_URL}/listcompanies`,
  EDIT_USER: `${API_BASE_URL}/edit_user`,
  EDIT_COMPANY:  `${API_BASE_URL}/edit_company`,
  LOGS: `${API_BASE_URL}/log`,
  GENERATE_PDF: `${API_BASE_URL}/generate-pdf`,
};
