import React, { createContext, useState, useContext, useEffect } from 'react';
import logoBiz from '../images/profile/logoBiz.svg';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState({
    id: '1',
    firstName: 'Иван',
    lastName: 'Иванов',
    role: 'volunteer',
    rating: 42,
    birthDate: '01.01.2000',
    organization: {
      name: 'Мой бизнес',
      organizer: 'Иван Иванов Иванович',
      description: 'Описание организации',
      img: logoBiz
    }
  });

  // Функция для загрузки данных организации с бэкенда
  const fetchOrganizationData = async (token) => {
    try {
      const authToken = token.startsWith('Bearer ') ? token : `Bearer ${token}`;
      
      const response = await fetch('http://127.0.0.1:8000/company/profile', {
        headers: {
          'Authorization': authToken,
          'Accept': 'application/json'
        },
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Ошибка загрузки профиля организации');
      }

      const data = await response.json();
      
      // Обновляем данные организации в состоянии пользователя
      setUser(prevUser => ({
        ...prevUser,
        organization: {
          name: data.name || 'Мой бизнес',
          organizer: data.organizer || 'Иван Иванов Иванович',
          description: data.description || 'Описание организации',
          img: data.icon_path ? `http://127.0.0.1:8000/${data.icon_path}` : logoBiz
        }
      }));
    } catch (error) {
      console.error('Ошибка при загрузке данных организации:', error);
    }
  };

  const toggleRole = () => {
    setUser(prevUser => {
      const newRole = prevUser.role === 'admin' ? 'volunteer' : 'admin';
      
      // Если переключаемся на роль организатора, загружаем данные с бэкенда
      if (newRole === 'admin') {
        const token = localStorage.getItem('token');
        if (token) {
          fetchOrganizationData(token);
        }
      }
      
      return {
        ...prevUser,
        role: newRole
      };
    });
  };

  const login = (userData) => {
    setUser(userData);
    
    // Если пользователь входит как организатор, загружаем данные с бэкенда
    if (userData.role === 'admin') {
      const token = localStorage.getItem('token');
      if (token) {
        fetchOrganizationData(token);
      }
    }
  };

  const logout = () => {
    setUser(null);
  };

  // Загружаем данные организации при монтировании компонента, если пользователь - организатор
  useEffect(() => {
    if (user && user.role === 'admin') {
      const token = localStorage.getItem('token');
      if (token) {
        fetchOrganizationData(token);
      }
    }
  }, [user?.role]);

  return (
    <AuthContext.Provider value={{ user, login, logout, toggleRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}; 